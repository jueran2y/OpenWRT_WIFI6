#ifndef __BT_HW_TEST_H__
#define __BT_HW_TEST_H__

//#include <linux/autoconf.h>
#include <stdio.h>

typedef unsigned long DWORD;
typedef unsigned long* PDWORD;
typedef unsigned long* LPDWORD;
typedef unsigned short USHORT;
typedef unsigned char UCHAR;
typedef unsigned char BYTE;
typedef unsigned char BOOL;
typedef unsigned long HANDLE;
typedef void VOID;
typedef void* LPCVOID;
typedef void* LPVOID;
typedef void* LPOVERLAPPED;
typedef unsigned char* PUCHAR;
typedef unsigned char* PBYTE;
typedef unsigned char* LPBYTE;

#define UART_SUPPORT 0
#define ETHERNET_SUPPORT 1

#define TRUE           1
#define FALSE          0

#define BT_RELAYER_DEBUG  1
#define ERR(f, ...)       printf("%s: " f, __func__, ##__VA_ARGS__)
#define WAN(f, ...)       printf("%s: " f, __func__, ##__VA_ARGS__)
#if BT_RELAYER_DEBUG
#define DBG(f, ...)       printf("%s: " f, __func__, ##__VA_ARGS__)
#define TRC(f)            printf("%s #%d", __func__, __LINE__)
#else
#define DBG(...)          ((void)0)
#define TRC(f)            ((void)0)
#endif

//#if (UART_SUPPORT)
#if defined(CONFIG_DEFAULTS_RALINK_MT7628) || defined(CONFIG_DEFAULTS_RALINK_MT7621)
#define SERIAL_DEVICE_NAME	"/dev/ttyS"
#elif defined(CONFIG_MACH_MT7623)
#define SERIAL_DEVICE_NAME	"/dev/ttyMT"
#else
#define SERIAL_DEVICE_NAME	"/dev/ttyS"
#endif
#define SERIAL_PORT_NUM		0
#define SERIAL_BAUDRATE		115200
//#endif /* UART_SUPPORT */

#if (ETHERNET_SUPPORT)
#define ETH_P_RACFG	0x7623
#define IF_NAME		"eth3"
#define ETH_HDR_SIZE	14


#ifdef big_endian
#define cpu2le64(x) SWAP64((x))
#define le2cpu64(x) SWAP64((x))
#define cpu2le32(x) SWAP32((x))
#define le2cpu32(x) SWAP32((x))
#define cpu2le16(x) SWAP16((x))
#define le2cpu16(x) SWAP16((x))
#define cpu2be64(x) ((UINT64)(x))
#define be2cpu64(x) ((UINT64)(x))
#define cpu2be32(x) ((UINT32)(x))
#define be2cpu32(x) ((UINT32)(x))
#define cpu2be16(x) ((UINT16)(x))
#define be2cpu16(x) ((UINT16)(x))

#else /* Little Endian */
#define cpu2le64(x) ((UINT64)(x))
#define le2cpu64(x) ((UINT64)(x))
#define cpu2le32(x) ((UINT32)(x))
#define le2cpu32(x) ((UINT32)(x))
#define cpu2le16(x) ((UINT16)(x))
#define le2cpu16(x) ((UINT16)(x))
#define cpu2be64(x) SWAP64((x))
#define be2cpu64(x) SWAP64((x))
#define cpu2be32(x) SWAP32((x))
#define be2cpu32(x) SWAP32((x))
#define cpu2be16(x) SWAP16((x))
#define be2cpu16(x) SWAP16((x))
#endif /* Big Endian */

#ifndef os_memcpy
#define os_memcpy(d, s, n) memcpy((d), (s), (n))
#endif

#ifndef os_memset
#define os_memset(s, c, n) memset(s, c, n)
#endif

#ifndef os_strlen
#define os_strlen(s) strlen(s)
#endif

#ifndef os_strncpy
#define os_strncpy(d, s, n) strncpy((d), (s), (n))
#endif

#ifndef os_strchr
#define os_strchr(s, c) strchr((s), (c))
#endif

#ifndef os_strstr
#define os_strstr(s, c) strstr((s), (c))
#endif

#ifndef os_strcmp
#define os_strcmp(s1, s2) strcmp((s1), (s2))
#endif

#endif /* ETHERNET_SUPPORT */

int init_serial(int port, int speed);
BOOL RELAYER_start(int serial_port, int serial_speed);
void RELAYER_exit();

#endif
