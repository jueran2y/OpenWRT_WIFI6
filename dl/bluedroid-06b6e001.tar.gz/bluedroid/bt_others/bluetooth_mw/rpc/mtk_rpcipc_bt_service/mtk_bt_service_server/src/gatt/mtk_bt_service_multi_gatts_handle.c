/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */


/*-----------------------------------------------------------------------------
                        include files
-----------------------------------------------------------------------------*/
#include <stdio.h>

#include "mtk_bt_service_multi_gatts.h"
#include "mtk_bt_service_multi_gatts_handle.h"
#include "mtk_bt_service_multi_gatt_ipcrpc_struct.h"
#include "ri_common.h"

GattsRegCbLinkList* pGattsLinkList = NULL;
static CHAR btaddr_zero[MAX_BDADDR_LEN] = "00:00:00:00:00:00";

#define BT_RH_LOG(_stmt...) \
        do{ \
            if(1){    \
                printf("Func:%s Line:%d--->: ", __FUNCTION__, __LINE__);   \
                printf(_stmt); \
                printf("\n"); \
            }        \
        }   \
        while(0)

/************************************************************************************/
/* Gatt multi server register api                       */
/****************************************/

VOID Multi_gatts_uuid_format(CHAR * uuid_fmt,  CHAR * app_uuid)
{
    INT32 i = 0,j = 0;
    INT32 size = 0;
    CHAR *ptr;
    CHAR  temp[3];
    CHAR  temp_uuid[16] = {0};
    CHAR  reverse_uuid[16];
    temp[2] = '\0';

    if (NULL == uuid_fmt || NULL == app_uuid)
    {
        return;
    }

    size = strlen(app_uuid);
    while (i < size)
    {
        if (app_uuid[i] == '-' || app_uuid[i] == '\0')
        {
            i++;
            continue;
        }
        temp[0] = app_uuid[i];
        temp[1] = app_uuid[i+1];
        temp_uuid[j] = strtoul(temp, NULL, 16);
        i+=2;
        j++;
    }

    if (size <= 8)
    {
        if (size == 4)
        {
            temp_uuid[2] = temp_uuid[0];
            temp_uuid[3] = temp_uuid[1];
            temp_uuid[0] = 0;
            temp_uuid[1] = 0;
        }
        temp_uuid[4] = 0x00;
        temp_uuid[5] = 0x00;
        temp_uuid[6] = 0x10;
        temp_uuid[7] = 0x00;

        temp_uuid[8] = 0x80;
        temp_uuid[9] = 0x00;
        temp_uuid[10] = 0x00;
        temp_uuid[11] = 0x80;

        temp_uuid[12] = 0x5F;
        temp_uuid[13] = 0x9B;
        temp_uuid[14] = 0x34;
        temp_uuid[15] = 0xFB;
    }
    for (i = 0; i < 16; i++)
    {
        reverse_uuid[i]= temp_uuid[15 - i];
    }

    ptr = uuid_fmt;
    for (i = 15; i >= 0; i--)
    {
        sprintf(ptr, "%02X", reverse_uuid[i]);
        ptr+=2;
        if (i == 12 || i == 10 || i == 8 || i == 6)
        {
            *ptr = '-';
            ptr++;
        }
    }
    *ptr = '\0';
}

static GattsRegCbLinkList* GattsRegCbLinkList_Create()
{
    BT_RH_LOG("Multi gatts create linklist start...");
    GattsRegCbLinkList* pLinkList = (GattsRegCbLinkList*)malloc(sizeof(GattsRegCbLinkList));
    if (NULL == pLinkList)
    {
        BT_RH_LOG("New gattsRegCbLinkList fail!");
        return NULL;
    }
    pLinkList->i4_size = 0;
    pLinkList->pHead = (GattsRegCbNode*)malloc(sizeof(GattsRegCbNode));
    if (NULL == pLinkList->pHead)
    {
        BT_RH_LOG("New gattsRegCbNode fail!");
        if (NULL != pLinkList)
        {
            free(pLinkList);
            pLinkList = NULL;
        }
        return NULL;
    }
    memset(&pLinkList->pHead->gatts_info, 0, sizeof(GattServerInfo));
    pLinkList->pHead->next = NULL;
    BT_RH_LOG("Multi gatts create linklist complete.");

    return pLinkList;
}

static INT32 GattsRegCbLinkList_FreeLinkList(GattsRegCbLinkList* pLinkList)
{
    BT_RH_LOG("Remove link list start...");
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return -1;
    }
    if (NULL == pLinkList->pHead)
    {
        free(pLinkList);
        pLinkList = NULL;
    }
    else
    {
        GattsRegCbNode* pCurrent = pLinkList->pHead->next;
        while (pCurrent != NULL)
        {
            pLinkList->pHead->next = pCurrent->next;
            if (NULL != pCurrent)
            {
                free(pCurrent);
                pCurrent = NULL;
                pLinkList->i4_size--;
            }
            pCurrent = pLinkList->pHead->next;
        }
        if (NULL != pLinkList->pHead)
        {
            free(pLinkList->pHead);
            pLinkList->pHead = NULL;
        }
        if (NULL != pLinkList && NULL == pLinkList->pHead)
        {
            free(pLinkList);
            pLinkList = NULL;
        }
    }
    BT_RH_LOG("Remove link list complete!");
    return 0;
}

/*********************************/
/* True:  uuid is exist
/* False: uuid is not exist
/*********************************/
static BOOL GattsRegCbLinkList_CheckUuidIsExist(GattsRegCbLinkList* pLinkList, CHAR * uuid)
{
    BT_RH_LOG("Check multi gatts uuid existence...");
    if (NULL == pLinkList || NULL == uuid)
    {
        BT_RH_LOG("Invalid parameter.");
        return FALSE;
    }
    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        if (0 == strncmp(pCurrent->gatts_info.bt_gatts_uuid, uuid, strlen(uuid)))
        {
            BT_RH_LOG("Multi gatts uuid is used. used_uuid = %s", pCurrent->gatts_info.bt_gatts_uuid);
            return TRUE;
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Check multi gatts uuid is not exist.");
    return FALSE;
}

static INT32 GattsRegCbLinkList_AddServerInfo(GattsRegCbLinkList* pLinkList, GattServerInfo* p_gatts_info)
{
    BT_RH_LOG("Add gatts info start...");
    if (NULL == pLinkList || NULL == p_gatts_info)
    {
        BT_RH_LOG("Invalid parameter.");
        return -1;
    }
    if (pLinkList->i4_size > GattServerRegMax)
    {
        BT_RH_LOG("Add gatts info exceeds the maximum %d.", GattServerRegMax);
        return -1;
    }
    GattsRegCbNode* pNode = (GattsRegCbNode*)malloc(sizeof(GattsRegCbNode));
    if (NULL == pNode)
    {
        BT_RH_LOG("New gatts info node fail.");
        return -1;
    }
    memcpy(&pNode->gatts_info, p_gatts_info, sizeof(GattServerInfo));
    pNode->next = NULL;
    GattsRegCbNode* pCurrent = pLinkList->pHead;
    while (pCurrent->next != NULL)
    {
        pCurrent = pCurrent->next;
    }
    pCurrent->next = pNode;
    pLinkList->i4_size++;
    BT_RH_LOG("Add gatts info complete.");
    return 0;
}

static INT32 GattsRegCbLinkList_RemoveServerCbkByUuid(GattsRegCbLinkList* pLinkList, CHAR* uuid)
{
    BT_RH_LOG("Remove gatts info start...");
    if (NULL == pLinkList || NULL == uuid)
    {
        BT_RH_LOG("Invalid parameter.");
        return -1;
    }
    if (0 == pLinkList->i4_size)
    {
        BT_RH_LOG("No available gatts info remove.");
        return 0;
    }
    GattsRegCbNode* pPre = pLinkList->pHead;
    GattsRegCbNode* pCurrent = pPre->next;
    while (pCurrent != NULL)
    {
        if (0 == strncmp(uuid, pCurrent->gatts_info.bt_gatts_uuid,
                         strlen(pCurrent->gatts_info.bt_gatts_uuid)))
        {
            pPre->next = pCurrent->next;
            if (NULL != pCurrent)
            {
                free(pCurrent);
                pCurrent = NULL;
            }
            BT_RH_LOG("Remove gatts info success. client_uuid = %s", uuid);
            pLinkList->i4_size--;
            return 0;
        }
        pPre = pCurrent;
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Remove gatts info fail!");
    return 0;
}

static GattServerInfo* GattsRegCbLinkList_AddServerif(GattsRegCbLinkList* pLinkList, BT_GATTS_REG_SERVER_RST_T *bt_reg_server_result)
{
    if (NULL == pLinkList || NULL == bt_reg_server_result)
    {
        BT_RH_LOG("Invalid parameter.");
        return NULL;
    }
    BT_RH_LOG("Multi gatts add server_if %d start...", bt_reg_server_result->server_if);

    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        BT_RH_LOG("pCurrent->gatts_info.bt_gatts_uuid=%s \n", pCurrent->gatts_info.bt_gatts_uuid);
        if (0 == strncmp(bt_reg_server_result->app_uuid, pCurrent->gatts_info.bt_gatts_uuid,
                         strlen(pCurrent->gatts_info.bt_gatts_uuid)))
        {
            pCurrent->gatts_info.server_if = bt_reg_server_result->server_if;
            BT_RH_LOG("Multi gatts add server_if %d success.", pCurrent->gatts_info.server_if);
            return &(pCurrent->gatts_info);
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Multi gatts add Server_if %d fail!", bt_reg_server_result->server_if);
    return NULL;
}

static INT32 GattsRegCbLinkList_RemoveServerif(GattsRegCbLinkList* pLinkList, INT32 server_if)
{
    BT_RH_LOG("Multi gatts remove server_if %d start...", server_if);
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return -1;
    }
    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        if (server_if == pCurrent->gatts_info.server_if)
        {
            pCurrent->gatts_info.server_if = -1;
            BT_RH_LOG("Multi gatts remove server_if %d success.", pCurrent->gatts_info.server_if);
            return 0;
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Multi gatts remove server_if %d fail!", server_if);
    return -1;
}

static GattServerInfo* GattsRegCbLinkList_AddConnIdAndAddr(GattsRegCbLinkList* pLinkList, BT_GATTS_CONNECT_RST_T *bt_gatts_connect_rst)
{
    if (NULL == pLinkList || NULL == bt_gatts_connect_rst)
    {
        BT_RH_LOG("Invalid parameter.");
        return NULL;
    }
    BT_RH_LOG("Multi gatts add conn_id %d start...", bt_gatts_connect_rst->conn_id);

    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        BT_RH_LOG("pCurrent->gatts_info.server_if = %d", pCurrent->gatts_info.server_if);
        if (pCurrent->gatts_info.server_if == bt_gatts_connect_rst->server_if)
        {
            for (UINT8 index = 0; index < ConnLinkMax; index++)
            {
                if (pCurrent->gatts_info.conn_info[index].conn_id == bt_gatts_connect_rst->conn_id)
                {
                     BT_RH_LOG("Multi gatts conn_id %d is exist.", pCurrent->gatts_info.conn_info[index].conn_id);
                               pCurrent->gatts_info.conn_info[index].in_use = TRUE;
                     strncpy(pCurrent->gatts_info.conn_info[index].btaddr, bt_gatts_connect_rst->btaddr, strlen(bt_gatts_connect_rst->btaddr));
                     return &(pCurrent->gatts_info);
                }
            }
            for (UINT8 index = 0; index < ConnLinkMax; index++)
            {
                if (pCurrent->gatts_info.conn_info[index].in_use == FALSE)
                {
                    pCurrent->gatts_info.conn_info[index].in_use = TRUE;
                    pCurrent->gatts_info.conn_info[index].conn_id = bt_gatts_connect_rst->conn_id;
                    strncpy(pCurrent->gatts_info.conn_info[index].btaddr, bt_gatts_connect_rst->btaddr, strlen(bt_gatts_connect_rst->btaddr));
                    if (0 == pCurrent->gatts_info.conn_info[index].conn_id)
                    {
                        BT_RH_LOG("Multi gatts add conn_id %d invalid!", pCurrent->gatts_info.conn_info[index].conn_id);
                    }
                    BT_RH_LOG("Multi gatts add conn_id %d success.", pCurrent->gatts_info.conn_info[index].conn_id);
                    return &(pCurrent->gatts_info);
                }
            }
            BT_RH_LOG("Multi gatts add conn_id %d fail, the connect link exceed the max val!", bt_gatts_connect_rst->conn_id);
            return NULL;
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Multi gatts add conn_id %d fail, no server_if match!", bt_gatts_connect_rst->conn_id);
    return NULL;
}

static GattServerInfo* GattsRegCbLinkList_RemoveConnIdAndAddr(GattsRegCbLinkList* pLinkList, BT_GATTS_CONNECT_RST_T *bt_gatts_connect_rst)
{
    if (NULL == pLinkList || NULL == bt_gatts_connect_rst)
    {
        BT_RH_LOG("Invalid parameter.");
        return NULL;
    }
    BT_RH_LOG("Multi gatts remove conn_id %d start...", bt_gatts_connect_rst->conn_id);

    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        BT_RH_LOG("pCurrent->gatts_info.server_if = %d \n", pCurrent->gatts_info.server_if);
        if (pCurrent->gatts_info.server_if == bt_gatts_connect_rst->server_if)
        {
            for (UINT8 index = 0; index < ConnLinkMax; index++)
            {
                if (pCurrent->gatts_info.conn_info[index].conn_id == bt_gatts_connect_rst->conn_id)
                {
                    pCurrent->gatts_info.conn_info[index].in_use = FALSE;
                    pCurrent->gatts_info.conn_info[index].conn_id = 0;
                    strncpy(pCurrent->gatts_info.conn_info[index].btaddr, btaddr_zero, strlen(btaddr_zero));
                    BT_RH_LOG("Multi gatts remove conn_id %d success.", bt_gatts_connect_rst->conn_id);
                    return &(pCurrent->gatts_info);
                }
            }
            BT_RH_LOG("Multi gatts remove conn_id %d fail, no conn_id match!", bt_gatts_connect_rst->conn_id);
            return &(pCurrent->gatts_info);
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Multi gatts remove conn_id %d fail!", bt_gatts_connect_rst->conn_id);
    return NULL;
}

static INT32 GattsRegCbLinkList_GetSize(GattsRegCbLinkList* pLinkList)
{
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return 0;
    }
    BT_RH_LOG("Get multi gatts linklist size. size=%d", pLinkList->i4_size);
    return pLinkList->i4_size;
}

static GattServerInfo* GattsRegCbLinkList_FindByServerif(GattsRegCbLinkList* pLinkList, INT32 server_if)
{
    BT_RH_LOG("Multi gatts find gatts info by server_if start...");
    BT_RH_LOG("The server_if is %d.", server_if);
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return NULL;
    }
    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        if (server_if == pCurrent->gatts_info.server_if)
        {
            BT_RH_LOG("Multi gatts find gatts info by server_if %d success.", pCurrent->gatts_info.server_if);
            return &(pCurrent->gatts_info);
        }
        pCurrent = pCurrent->next;
    }
    BT_RH_LOG("Multi gatts find gatts info by server_if %d fail!", server_if);
    return NULL;
}

static GattServerInfo* GattsRegCbLinkList_FindByConnId(GattsRegCbLinkList* pLinkList, INT32 conn_id)
{
    BT_RH_LOG("Multi gatts find gatts info by conn_id start...");
    BT_RH_LOG("The conn_id is %d.", conn_id);
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return NULL;
    }
    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while(pCurrent != NULL)
    {
        BT_RH_LOG("pCurrent->gatts_info.server_if = %d \n", pCurrent->gatts_info.server_if);
        for (UINT8 index = 0; index < ConnLinkMax; index++)
        {
            BT_RH_LOG("pCurrent->gatts_info.conn_info[%d].conn_id = %d \n", index, pCurrent->gatts_info.conn_info[index].conn_id);
            if (conn_id == pCurrent->gatts_info.conn_info[index].conn_id && pCurrent->gatts_info.conn_info[index].in_use)
            {
                BT_RH_LOG("Multi gatts find gatts info by conn_id %d success.", pCurrent->gatts_info.conn_info[index].conn_id);
                return &(pCurrent->gatts_info);
            }
        }
        pCurrent = pCurrent->next;
    }

    BT_RH_LOG("Multi gatts find gatts info by conn_id %d fail!", conn_id);
    return NULL;
}

static VOID GattsRegCbLinkList_Show(GattsRegCbLinkList* pLinkList)
{
    BT_RH_LOG("Show all multi gatts info...");
    if (NULL == pLinkList)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("Multi gatts register number is %d.", pLinkList->i4_size);
    GattsRegCbNode* pCurrent = pLinkList->pHead->next;
    while (pCurrent != NULL)
    {
        BT_RH_LOG("uuid = %s", pCurrent->gatts_info.bt_gatts_uuid);
        BT_RH_LOG("server_if = %d", pCurrent->gatts_info.server_if);
        BT_RH_LOG("rpc_id = %d", pCurrent->gatts_info.t_id);
        for(UINT8 index = 0; index < ConnLinkMax; index++)
        {
            BT_RH_LOG("conn_info[%d].in_use = %d", index, pCurrent->gatts_info.conn_info[index].in_use);
            BT_RH_LOG("conn_info[%d].conn_id = %d", index, pCurrent->gatts_info.conn_info[index].conn_id);
            BT_RH_LOG("conn_info[%d].btaddr = %s", index, pCurrent->gatts_info.conn_info[index].btaddr);
        }
        pCurrent = pCurrent->next;
    }
}

static VOID bt_app_multi_gatts_event_cbk_agent(BT_GATTS_EVENT_T bt_gatts_event,
                                                        BT_GATTS_CONNECT_RST_T *bt_gatts_connect_rst,
                                                        void* pv_tag)
{
    if (NULL == bt_gatts_connect_rst)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    INT32 server_if = bt_gatts_connect_rst->server_if;
    INT32 conn_id = bt_gatts_connect_rst ->conn_id;
    BT_RH_LOG("Multi gatts event callback agent. server_if=%d, conn_id=%d.", server_if, conn_id);
    GattServerInfo* gatts_info = NULL;
    switch(bt_gatts_event)
    {
        case BT_GATTS_REGISTER_SERVER:
            BT_RH_LOG("-> BT_GATTS_REGISTER_SERVER: \n");
            break;
        case BT_GATTS_CONNECT:
            BT_RH_LOG("-> BT_GATTS_CONNECT: \n");
            gatts_info = GattsRegCbLinkList_AddConnIdAndAddr(pGattsLinkList, bt_gatts_connect_rst);
            break;
        case BT_GATTS_DISCONNECT:
            BT_RH_LOG("-> BT_GATTC_DISCONNECT: \n");
            gatts_info = GattsRegCbLinkList_RemoveConnIdAndAddr(pGattsLinkList, bt_gatts_connect_rst);
            break;
        case BT_GATTS_GET_RSSI_DONE:
            BT_RH_LOG("-> BT_GATTC_GET_RSSI_DONE: \n");
            gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, server_if);
            break;
    }
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_multi_gatts_event_cb)
    {
        BT_RH_LOG("Multi Gatts server_if=%d event callback is not register", bt_gatts_connect_rst->server_if);
        return;
    }
    RPC_DECL_VOID(3);
    RPC_CB_NFY_TAG_T  *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[0] = gatts_info->app_func.bt_multi_gatts_event_cb;
    RPC_ARG_INP(ARG_TYPE_INT32, bt_gatts_event);
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_connect_rst, RPC_DESC_BT_GATTS_CONNECT_RST_T, NULL));
    RPC_CHECK(bt_rpc_add_ref_buff(RPC_DEFAULT_ID, bt_gatts_connect_rst->btaddr, MAX_BDADDR_LEN));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_connect_rst);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_event_cbk_agent, rpc_id = %d, pt_nfy_tag->apv_cb_addr_ex[0] = %p",
               pt_nfy_tag->t_id, pt_nfy_tag->apv_cb_addr_ex[0]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_event_cbk", pt_nfy_tag->apv_cb_addr_ex[0]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_reg_server_cbk_agent(BT_GATTS_REG_SERVER_RST_T *bt_gatts_reg_server,
                                                              void* pv_tag)
{
    BT_RH_LOG("Multi gatts register server callback agent.");
    if (NULL == bt_gatts_reg_server)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_uuid = %s, server_if = %d", bt_gatts_reg_server->app_uuid, bt_gatts_reg_server->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_AddServerif(pGattsLinkList, bt_gatts_reg_server);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_reg_server_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d register callback is not register.", bt_gatts_reg_server->server_if);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[1] = gatts_info->app_func.bt_gatts_reg_server_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_reg_server,
                                  RPC_DESC_BT_GATTS_REG_SERVER_RST_T, NULL));
    RPC_CHECK(bt_rpc_add_ref_buff(RPC_DEFAULT_ID, bt_gatts_reg_server->app_uuid,
                                  BT_GATT_MAX_UUID_LEN));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_reg_server);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_reg_server_cbk_agent, server_if = %d, pt_nfy_tag->apv_cb_addr_ex[1] = %p\n",
               bt_gatts_reg_server->server_if, pt_nfy_tag->apv_cb_addr_ex[1]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_reg_server_cbk", pt_nfy_tag->apv_cb_addr_ex[1]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_add_srvc_cbk_agent(BT_GATTS_ADD_SRVC_RST_T *bt_gatts_add_srvc,
                                                           void* pv_tag)
{
    BT_RH_LOG("Multi gatts add service callback agent.");
    if (NULL == bt_gatts_add_srvc)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_if = %d", bt_gatts_add_srvc->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, bt_gatts_add_srvc->server_if);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_add_srvc_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d add service callback is not register.", bt_gatts_add_srvc->server_if);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[2] = gatts_info->app_func.bt_gatts_add_srvc_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_add_srvc,
                                  RPC_DESC_BT_GATTS_ADD_SRVC_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_add_srvc);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_add_srvc_cbk_agent, uuid = %s, pt_nfy_tag->apv_cb_addr_ex[2] = %p\n",
                bt_gatts_add_srvc->srvc_id.id.uuid, pt_nfy_tag->apv_cb_addr_ex[2]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_add_srvc_cbk", pt_nfy_tag->apv_cb_addr_ex[2]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_add_incl_cbk_agent(BT_GATTS_ADD_INCL_RST_T *bt_gatts_add_incl,
                                                          void* pv_tag)
{
    BT_RH_LOG("Multi gatts add included callback agent.");
    if (NULL == bt_gatts_add_incl)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_if = %d", bt_gatts_add_incl->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, bt_gatts_add_incl->server_if);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_add_incl_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d add included callback is not register.", bt_gatts_add_incl->server_if);
        return;
    }

    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[3] = gatts_info->app_func.bt_gatts_add_incl_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_add_incl,
                                  RPC_DESC_BT_GATTS_ADD_INCL_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_add_incl);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_add_incl_cbk_agent, incl_srvc_handle = %d, pt_nfy_tag->apv_cb_addr_ex[3] = %p\n",
                bt_gatts_add_incl->incl_srvc_handle, pt_nfy_tag->apv_cb_addr_ex[3]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_add_incl_cbk", pt_nfy_tag->apv_cb_addr_ex[3]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_add_char_cbk_agent(BT_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char,
                                                           void* pv_tag)
{
    BT_RH_LOG("Multi gatts add characteristic callback agent.");
    if (NULL == bt_gatts_add_char)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_if = %d", bt_gatts_add_char->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, bt_gatts_add_char->server_if);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_add_char_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d add characteristic callback is not register.", bt_gatts_add_char->server_if);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[4] = gatts_info->app_func.bt_gatts_add_char_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_add_char,
                                  RPC_DESC_BT_GATTS_ADD_CHAR_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_add_char);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_add_char_cbk_agent, uuid = %s, pt_nfy_tag->apv_cb_addr_ex[4] = %p\n",
                bt_gatts_add_char->uuid, pt_nfy_tag->apv_cb_addr_ex[4]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_add_char_cbk", pt_nfy_tag->apv_cb_addr_ex[4]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_add_desc_cbk_agent(BT_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc,
                                                            void* pv_tag)
{
    BT_RH_LOG("Multi gatts add descriptor callback agent.");
    if (NULL == bt_gatts_add_desc)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_if = %d", bt_gatts_add_desc->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, bt_gatts_add_desc->server_if);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_add_desc_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d add descriptor callback is not register.", bt_gatts_add_desc->server_if);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[5] = gatts_info->app_func.bt_gatts_add_desc_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_add_desc,
                                  RPC_DESC_BT_GATTS_ADD_DESCR_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_add_desc);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_add_desc_cbk_agent, uuid = %s, pt_nfy_tag->apv_cb_addr_ex[5] = %p\n",
                bt_gatts_add_desc->uuid, pt_nfy_tag->apv_cb_addr_ex[5]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_add_desc_cbk", pt_nfy_tag->apv_cb_addr_ex[5]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_op_srvc_cbk_agent(BT_GATTS_SRVC_OP_TYPE_T op_type,
                                                          BT_GATTS_SRVC_RST_T *bt_gatts_srvc,
                                                          void* pv_tag)
{
    BT_RH_LOG("Multi gatts operate service callback agent.");
    if (NULL == bt_gatts_srvc)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("server_if = %d", bt_gatts_srvc->server_if);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByServerif(pGattsLinkList, bt_gatts_srvc->server_if);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_op_srvc_cb)
    {
        BT_RH_LOG("Multi gatts server_if=%d operate service callback is not register.", bt_gatts_srvc->server_if);
        return;
    }
    RPC_DECL_VOID(3);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[6] = gatts_info->app_func.bt_gatts_op_srvc_cb;
    RPC_ARG_INP(ARG_TYPE_INT32, op_type);
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_srvc,
                                  RPC_DESC_BT_GATTS_SRVC_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_srvc);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_op_srvc_cbk_agent, srvc_handle = %ld, pt_nfy_tag->apv_cb_addr_ex[6] = %p\n",
                (long)bt_gatts_srvc->srvc_handle, pt_nfy_tag->apv_cb_addr_ex[6]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_op_srvc_cbk", pt_nfy_tag->apv_cb_addr_ex[6]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_req_read_cbk_agent(BT_GATTS_REQ_READ_RST_T *bt_gatts_read,
                                                           void* pv_tag)
{
    BT_RH_LOG("Multi gatts request read callback agent.");
    if (NULL == bt_gatts_read)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("conn_id = %d", bt_gatts_read->conn_id);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByConnId(pGattsLinkList, bt_gatts_read->conn_id);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_req_read_cb)
    {
        BT_RH_LOG("Multi gatts conn_id=%d request read callback is not register.", bt_gatts_read->conn_id);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[7] = gatts_info->app_func.bt_gatts_req_read_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_read,
                                  RPC_DESC_BT_GATTS_REQ_READ_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_read);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_req_read_cbk_agent, attr_handle = %ld, pt_nfy_tag->apv_cb_addr_ex[7] = %p\n",
                (long)bt_gatts_read->attr_handle, pt_nfy_tag->apv_cb_addr_ex[7]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_req_read_cbk", pt_nfy_tag->apv_cb_addr_ex[7]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_req_write_cbk_agent(BT_GATTS_REQ_WRITE_RST_T *bt_gatts_write,
                                                            void* pv_tag)
{
    BT_RH_LOG("Multi gatts request write callback agent.");
    if (NULL == bt_gatts_write)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("conn_id = %d", bt_gatts_write->conn_id);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByConnId(pGattsLinkList, bt_gatts_write->conn_id);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_req_write_cb)
    {
        BT_RH_LOG("Multi gatts conn_id=%d request write callback is not register.", bt_gatts_write->conn_id);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[8] = gatts_info->app_func.bt_gatts_req_write_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, bt_gatts_write,
                                  RPC_DESC_BT_GATTS_REQ_WRITE_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, bt_gatts_write);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_req_write_cbk_agent, value = %s, pt_nfy_tag->apv_cb_addr_ex[8] = %p\n",
                bt_gatts_write->value, pt_nfy_tag->apv_cb_addr_ex[8]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_req_write_cbk", pt_nfy_tag->apv_cb_addr_ex[8]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_ind_sent_cbk_agent(INT32 conn_id,
                                                           INT32 status,
                                                           void *pv_tag)
{
    BT_RH_LOG("Multi gatts indicate sent callback agent.");
    BT_RH_LOG("conn_id = %d, status = %d", conn_id, status);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByConnId(pGattsLinkList, conn_id);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_ind_sent_cb)
    {
        BT_RH_LOG("Multi gatts conn_id=%d indicate sent callback is not register.", conn_id);
        return;
    }
    RPC_DECL_VOID(3);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[9] = gatts_info->app_func.bt_gatts_ind_sent_cb;
    RPC_ARG_INP(ARG_TYPE_INT32, conn_id);
    RPC_ARG_INP(ARG_TYPE_INT32, status);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_ind_sent_cbk_agent, conn_id = %d, status = %d, pt_nfy_tag->apv_cb_addr_ex[9] = %p\n",
               conn_id, status, pt_nfy_tag->apv_cb_addr_ex[9]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_ind_sent_cbk", pt_nfy_tag->apv_cb_addr_ex[9]);
    RPC_RETURN_VOID;
}

static VOID bt_app_multi_gatts_config_mtu_cbk_agent(BT_GATTS_CONFIG_MTU_RST_T *pt_config_mtu_result, void* pv_tag)
{
    BT_RH_LOG("Multi gatts configure mtu callback agent.");
    if (NULL == pt_config_mtu_result)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("conn_id = %d", pt_config_mtu_result->conn_id);

#if !defined(MTK_LINUX_C4A_BLE_SETUP)
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByConnId(pGattsLinkList, pt_config_mtu_result->conn_id);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_config_mtu_cb)
    {
        BT_RH_LOG("Multi gatts conn_id=%d configure mtu callback is not register.", pt_config_mtu_result->conn_id);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[10] = gatts_info->app_func.bt_gatts_config_mtu_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, pt_config_mtu_result, RPC_DESC_BT_GATTS_CONFIG_MTU_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, pt_config_mtu_result);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_config_mtu_cbk_agent, conn_id = %d, mtu = %d,pt_nfy_tag->apv_cb_addr_ex[10] = %p\n",
              pt_config_mtu_result->conn_id, pt_config_mtu_result->mtu, pt_nfy_tag->apv_cb_addr_ex[10]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_config_mtu_cbk", pt_nfy_tag->apv_cb_addr_ex[10]);
    RPC_RETURN_VOID;
#endif
}

static VOID bt_app_multi_gatts_exec_write_cbk_agent(BT_GATTS_EXEC_WRITE_RST_T *pt_exec_write_result, void* pv_tag)
{
    BT_RH_LOG("Multi gatts execute write callback agent.");
    if (NULL == pt_exec_write_result)
    {
        BT_RH_LOG("Invalid parameter.");
        return;
    }
    BT_RH_LOG("conn_id = %d", pt_exec_write_result->conn_id);
    GattServerInfo* gatts_info;
    gatts_info = GattsRegCbLinkList_FindByConnId(pGattsLinkList, pt_exec_write_result->conn_id);
    if (NULL == gatts_info || NULL == gatts_info->app_func.bt_gatts_exec_write_cb)
    {
        BT_RH_LOG("Multi gatts conn_id=%d execute write callback is not register.", pt_exec_write_result->conn_id);
        return;
    }
    RPC_DECL_VOID(2);
    RPC_CB_NFY_TAG_T *pt_nfy_tag = (RPC_CB_NFY_TAG_T*)pv_tag;
    pt_nfy_tag->t_id = gatts_info->t_id;
    pt_nfy_tag->apv_cb_addr_ex[11] = gatts_info->app_func.bt_gatts_exec_write_cb;
    RPC_CHECK(bt_rpc_add_ref_desc(RPC_DEFAULT_ID, pt_exec_write_result, RPC_DESC_BT_GATTS_EXEC_WRITE_RST_T, NULL));
    RPC_ARG_IO(ARG_TYPE_REF_DESC, pt_exec_write_result);
    RPC_ARG_INP(ARG_TYPE_REF_VOID, pt_nfy_tag->pv_tag);
    BT_RH_LOG("[_hndlr_]bt_app_multi_gatts_exec_write_cbk_agent, conn_id = %d, exec_write = %d,pt_nfy_tag->apv_cb_addr_ex[11] = %p\n",
              pt_exec_write_result->conn_id, pt_exec_write_result->exec_write, pt_nfy_tag->apv_cb_addr_ex[11]);
    RPC_DO_CB(pt_nfy_tag->t_id, "bt_app_multi_gatts_exec_write_cbk", pt_nfy_tag->apv_cb_addr_ex[11]);
    RPC_RETURN_VOID;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_register_callback(RPC_ID_T     t_rpc_id,
                                                                    const CHAR*  ps_cb_type,
                                                                    UINT32       ui4_num_args,
                                                                    ARG_DESC_T*  pt_args,
                                                                    ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("Multi gatts register callback start...");
    if (ui4_num_args != 3)
    {
        return RPCR_INV_ARGS;
    }
    pt_return->e_type = ARG_TYPE_INT32;
    pt_return->u.i4_arg = 0;
/*******************************************************************/
/*       The first server need create pGattsLinkList when register callback           */
/*******************************************************************/
    if (NULL == pGattsLinkList)
    {
        pGattsLinkList = GattsRegCbLinkList_Create();
        RPC_CB_NFY_TAG_T * pt_nfy_tag = NULL;
        VOID * apv_cb_addr[12] = {0};
        MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T bt_app_cb_func;
        memset(&bt_app_cb_func,0,sizeof(MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T));

        bt_app_cb_func.bt_multi_gatts_event_cb = bt_app_multi_gatts_event_cbk_agent;
        bt_app_cb_func.bt_gatts_reg_server_cb = bt_app_multi_gatts_reg_server_cbk_agent;
        bt_app_cb_func.bt_gatts_add_srvc_cb = bt_app_multi_gatts_add_srvc_cbk_agent;
        bt_app_cb_func.bt_gatts_add_incl_cb = bt_app_multi_gatts_add_incl_cbk_agent;
        bt_app_cb_func.bt_gatts_add_char_cb = bt_app_multi_gatts_add_char_cbk_agent;
        bt_app_cb_func.bt_gatts_add_desc_cb = bt_app_multi_gatts_add_desc_cbk_agent;
        bt_app_cb_func.bt_gatts_op_srvc_cb = bt_app_multi_gatts_op_srvc_cbk_agent;
        bt_app_cb_func.bt_gatts_req_read_cb = bt_app_multi_gatts_req_read_cbk_agent;
        bt_app_cb_func.bt_gatts_req_write_cb = bt_app_multi_gatts_req_write_cbk_agent;
        bt_app_cb_func.bt_gatts_ind_sent_cb = bt_app_multi_gatts_ind_sent_cbk_agent;
#if !defined(MTK_LINUX_C4A_BLE_SETUP)
        bt_app_cb_func.bt_gatts_config_mtu_cb = bt_app_multi_gatts_config_mtu_cbk_agent;
#endif
        bt_app_cb_func.bt_gatts_exec_write_cb = bt_app_multi_gatts_exec_write_cbk_agent;
        pt_nfy_tag = ri_create_cb_tag(t_rpc_id, apv_cb_addr, 12, pt_args[2].u.pv_arg);
        pt_return->e_type = ARG_TYPE_INT32;
        pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_register_callback(&bt_app_cb_func, pt_nfy_tag);
        if (pt_return->u.i4_arg && pt_nfy_tag != NULL)
        {
            ri_free_cb_tag(pt_nfy_tag);
        }
    }
/*******************************************************************/
/*        Add server callback to  pGattsLinkList                                                */
/*******************************************************************/
    CHAR * app_uuid = pt_args[0].u.pc_arg;
    CHAR uuid_fmt[UuidLengthMax] = {0};
    BT_RH_LOG("Multi gatts register callback. app_uuid = %s", app_uuid);
    INT32 i4_ret;
    if (TRUE == GattsRegCbLinkList_CheckUuidIsExist(pGattsLinkList, app_uuid))
    {
        BT_RH_LOG("Multi gattc register app_uuid %s is exist.", app_uuid);
        return RPCR_EXIST;
    }
    MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T* server_app_cb_func = (MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T*)pt_args[1].u.pv_desc;
    GattServerInfo* p_gatts_info = (GattServerInfo*)malloc(sizeof(GattServerInfo));
    if (NULL == p_gatts_info)
    {
        BT_RH_LOG("New gatts info fail.");
        return RPCR_ERROR;
    }
    memset(p_gatts_info, 0, sizeof(GattServerInfo));
    Multi_gatts_uuid_format(uuid_fmt, app_uuid);
    strncpy(p_gatts_info->bt_gatts_uuid, uuid_fmt, strlen(uuid_fmt));
    p_gatts_info->t_id = t_rpc_id;
    p_gatts_info->server_if = -1;
    for (UINT8 index = 0; index < ConnLinkMax; index++)
    {
        p_gatts_info->conn_info[index].in_use = FALSE;
        p_gatts_info->conn_info[index].conn_id = 0;
        strncpy(p_gatts_info->conn_info[index].btaddr, btaddr_zero, sizeof(btaddr_zero));
    }
    BT_RH_LOG("p_gatts_info->t_id = %d", p_gatts_info->t_id);
    BT_RH_LOG("p_gatts_info->bt_gatts_uuid = %s", p_gatts_info->bt_gatts_uuid);
    if (NULL != server_app_cb_func->bt_multi_gatts_event_cb)
    {
        p_gatts_info->app_func.bt_multi_gatts_event_cb = server_app_cb_func->bt_multi_gatts_event_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_reg_server_cb)
    {
        p_gatts_info->app_func.bt_gatts_reg_server_cb= server_app_cb_func->bt_gatts_reg_server_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_add_srvc_cb)
    {
        p_gatts_info->app_func.bt_gatts_add_srvc_cb = server_app_cb_func->bt_gatts_add_srvc_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_add_incl_cb)
    {
        p_gatts_info->app_func.bt_gatts_add_incl_cb = server_app_cb_func->bt_gatts_add_incl_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_add_char_cb)
    {
        p_gatts_info->app_func.bt_gatts_add_char_cb = server_app_cb_func->bt_gatts_add_char_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_add_desc_cb)
    {
        p_gatts_info->app_func.bt_gatts_add_desc_cb = server_app_cb_func->bt_gatts_add_desc_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_op_srvc_cb)
    {
        p_gatts_info->app_func.bt_gatts_op_srvc_cb = server_app_cb_func->bt_gatts_op_srvc_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_req_read_cb)
    {
        p_gatts_info->app_func.bt_gatts_req_read_cb = server_app_cb_func->bt_gatts_req_read_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_req_write_cb)
    {
        p_gatts_info->app_func.bt_gatts_req_write_cb = server_app_cb_func->bt_gatts_req_write_cb;
    }
    if (NULL != server_app_cb_func->bt_gatts_ind_sent_cb)
    {
        p_gatts_info->app_func.bt_gatts_ind_sent_cb = server_app_cb_func->bt_gatts_ind_sent_cb;
    }
#if !defined(MTK_LINUX_C4A_BLE_SETUP)
    if (NULL != server_app_cb_func->bt_gatts_config_mtu_cb)
    {
        p_gatts_info->app_func.bt_gatts_config_mtu_cb = server_app_cb_func->bt_gatts_config_mtu_cb;
    }
#endif
    if (NULL != server_app_cb_func->bt_gatts_exec_write_cb)
    {
        p_gatts_info->app_func.bt_gatts_exec_write_cb = server_app_cb_func->bt_gatts_exec_write_cb;
    }

    i4_ret = GattsRegCbLinkList_AddServerInfo(pGattsLinkList, p_gatts_info);
    if(i4_ret != 0)
    {
        BT_RH_LOG("Multi gatts register callback fail!");
    }
    BT_RH_LOG("Multi gatts register callback complete.");
    if(NULL != p_gatts_info)
    {
        free(p_gatts_info);
        p_gatts_info = NULL;
    }
    GattsRegCbLinkList_Show(pGattsLinkList);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_register_server(RPC_ID_T     t_rpc_id,
                                                                   const CHAR*  ps_cb_type,
                                                                   UINT32       ui4_num_args,
                                                                   ARG_DESC_T*  pt_args,
                                                                   ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_register_server, arg_1 = %s\n", pt_args[0].u.pc_arg);
    if (ui4_num_args != 1)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    CHAR * app_uuid = pt_args[0].u.pc_arg;
    BT_RH_LOG("Multi gatts register app. app_uuid = %s", app_uuid);
    CHAR uuid_fmt[UuidLengthMax] = {0};
    Multi_gattc_uuid_format(uuid_fmt, app_uuid);
    if(FALSE == GattsRegCbLinkList_CheckUuidIsExist(pGattsLinkList, uuid_fmt))
    {
        BT_RH_LOG("Multi gatts register app_uuid %s is not exist.", app_uuid);
        return RPCR_NOT_FOUND;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_register_server(pt_args[0].u.pc_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_unregister_server(RPC_ID_T     t_rpc_id,
                                                                      const CHAR*  ps_cb_type,
                                                                      UINT32       ui4_num_args,
                                                                      ARG_DESC_T*  pt_args,
                                                                      ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_unregister_server, arg_1 = %d\n", pt_args[0].u.i4_arg);
    if (ui4_num_args != 1)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    INT32 server_if = pt_args[0].u.i4_arg;
    INT32 i4_ret = GattsRegCbLinkList_RemoveServerif(pGattsLinkList, server_if);
    if(0 != i4_ret)
    {
        BT_RH_LOG("Multi gatts unregister app fail!");
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_unregister_server(pt_args[0].u.i4_arg);
    return RPCR_OK;
}


static INT32 _hndlr_x_mtkapi_bt_multi_gatts_connect(RPC_ID_T     t_rpc_id,
                                                     const CHAR*  ps_cb_type,
                                                     UINT32       ui4_num_args,
                                                     ARG_DESC_T*  pt_args,
                                                     ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_open, arg_1 = %d, arg_2 = %s, arg_3 = %d, arg_4 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.pc_arg, pt_args[2].u.ui1_arg, pt_args[3].u.i4_arg);
    if (ui4_num_args != 4)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_connect(pt_args[0].u.i4_arg,
                                                    pt_args[1].u.pc_arg,
                                                    pt_args[2].u.ui1_arg,
                                                    pt_args[3].u.i4_arg);
    return RPCR_OK;
}


static INT32 _hndlr_x_mtkapi_bt_multi_gatts_disconnect(RPC_ID_T     t_rpc_id,
                                                             const CHAR*  ps_cb_type,
                                                             UINT32       ui4_num_args,
                                                             ARG_DESC_T*  pt_args,
                                                             ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_close, arg_1 = %d, arg_2 = %s, arg_3 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.pc_arg, pt_args[2].u.i4_arg);
    if (ui4_num_args != 3)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_disconnect(pt_args[0].u.i4_arg,
                                                       pt_args[1].u.pc_arg,
                                                       pt_args[2].u.i4_arg);

    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_add_service(RPC_ID_T     t_rpc_id,
                                                               const CHAR*  ps_cb_type,
                                                               UINT32       ui4_num_args,
                                                               ARG_DESC_T*  pt_args,
                                                               ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_add_service, arg_1 = %d, arg_2 = %s, arg_3 = %u, arg_4 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.pc_arg, pt_args[2].u.ui1_arg, pt_args[3].u.i4_arg);
    if (ui4_num_args != 4)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_add_service(pt_args[0].u.i4_arg,
                                                        pt_args[1].u.pc_arg,
                                                        pt_args[2].u.ui1_arg,
                                                        pt_args[3].u.i4_arg);

    return RPCR_OK;
}


static INT32 _hndlr_x_mtkapi_bt_multi_gatts_add_included_service(RPC_ID_T     t_rpc_id,
                                                                           const CHAR*  ps_cb_type,
                                                                           UINT32       ui4_num_args,
                                                                           ARG_DESC_T*  pt_args,
                                                                           ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_add_included_service, arg_1 = %d, arg_2 = %d, arg_3 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg, pt_args[2].u.i4_arg);
    if (ui4_num_args != 3)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_add_included_service(pt_args[0].u.i4_arg,
                                                                 pt_args[1].u.i4_arg,
                                                                 pt_args[2].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_add_char(RPC_ID_T     t_rpc_id,
                                                           const CHAR*  ps_cb_type,
                                                           UINT32       ui4_num_args,
                                                           ARG_DESC_T*  pt_args,
                                                           ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_add_char, arg_1 = %d, arg_2 = %d, arg_3 = %s\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg,pt_args[2].u.pc_arg);
    if (ui4_num_args != 5)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_add_char(pt_args[0].u.i4_arg,
                                                     pt_args[1].u.i4_arg,
                                                     pt_args[2].u.pc_arg,
                                                     pt_args[3].u.i4_arg,
                                                     pt_args[4].u.i4_arg);

    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_add_desc(RPC_ID_T     t_rpc_id,
                                                           const CHAR*  ps_cb_type,
                                                           UINT32       ui4_num_args,
                                                           ARG_DESC_T*  pt_args,
                                                           ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_add_desc, arg_1 = %d, arg_2 = %d, arg_3 = %s\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg,pt_args[2].u.pc_arg);
    if (ui4_num_args != 4)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_add_desc(pt_args[0].u.i4_arg,
                                                     pt_args[1].u.i4_arg,
                                                     pt_args[2].u.pc_arg,
                                                     pt_args[3].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_start_service(RPC_ID_T     t_rpc_id,
                                                                const CHAR*  ps_cb_type,
                                                                UINT32       ui4_num_args,
                                                                ARG_DESC_T*  pt_args,
                                                                ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_start_service, arg_1 = %d, arg_2 = %d, arg_3 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg, pt_args[2].u.i4_arg);
    if (ui4_num_args != 3)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_start_service(pt_args[0].u.i4_arg,
                                                          pt_args[1].u.i4_arg,
                                                          pt_args[2].u.i4_arg);

    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_stop_service(RPC_ID_T     t_rpc_id,
                                                                const CHAR*  ps_cb_type,
                                                                UINT32       ui4_num_args,
                                                                ARG_DESC_T*  pt_args,
                                                                ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_stop_service, arg_1 = %d, arg_2 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg);
    if (ui4_num_args != 2)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_stop_service(pt_args[0].u.i4_arg,
                                                         pt_args[1].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_delete_service(RPC_ID_T     t_rpc_id,
                                                                  const CHAR*  ps_cb_type,
                                                                  UINT32       ui4_num_args,
                                                                  ARG_DESC_T*  pt_args,
                                                                  ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_delete_service, arg_1 = %d, arg_2 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg);
    if (ui4_num_args != 2)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_delete_service(pt_args[0].u.i4_arg,
                                                           pt_args[1].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_send_indication(RPC_ID_T     t_rpc_id,
                                                                   const CHAR*  ps_cb_type,
                                                                   UINT32       ui4_num_args,
                                                                   ARG_DESC_T*  pt_args,
                                                                   ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_send_indication, arg_1 = %d, arg_2 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg);
    if (ui4_num_args != 6)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_send_indication(pt_args[0].u.i4_arg,
                                                            pt_args[1].u.i4_arg,
                                                            pt_args[2].u.i4_arg,
                                                            pt_args[3].u.i4_arg,
                                                            pt_args[4].u.pc_arg,
                                                            pt_args[5].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_send_response(RPC_ID_T     t_rpc_id,
                                                                   const CHAR*  ps_cb_type,
                                                                   UINT32       ui4_num_args,
                                                                   ARG_DESC_T*  pt_args,
                                                                   ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]x_mtkapi_bt_multi_gatts_send_response, arg_1 = %d, arg_2 = %d\n",
        pt_args[0].u.i4_arg, pt_args[1].u.i4_arg);
    if (ui4_num_args != 7)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_send_response(pt_args[0].u.i4_arg,
                                                          pt_args[1].u.i4_arg,
                                                          pt_args[2].u.i4_arg,
                                                          pt_args[3].u.i4_arg,
                                                          pt_args[4].u.pc_arg,
                                                          pt_args[5].u.i4_arg,
                                                          pt_args[6].u.i4_arg);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_unregister_callback(RPC_ID_T     t_rpc_id,
                                                                          const CHAR*  ps_cb_type,
                                                                          UINT32       ui4_num_args,
                                                                          ARG_DESC_T*  pt_args,
                                                                          ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]bt_gatts_unregister_callback, arg_0 = %s\n", pt_args[0].u.pc_arg);
    if (ui4_num_args != 2)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = 0;
    CHAR *app_uuid = pt_args[0].u.pc_arg;
    CHAR uuid_fmt[UuidLengthMax] = {0};
    Multi_gatts_uuid_format(uuid_fmt, app_uuid);
    INT32 i4_ret = GattsRegCbLinkList_RemoveServerCbkByUuid(pGattsLinkList, uuid_fmt);
    if (0 != i4_ret)
    {
        BT_RH_LOG("Multi gatts unregister callback fail! unregister uuid = %s", app_uuid);
    }
    GattsRegCbLinkList_Show(pGattsLinkList);
    if (0 == GattsRegCbLinkList_GetSize(pGattsLinkList))
    {
        pt_return->u.i4_arg = x_mtkapi_bt_multi_gatts_unregister_callback();
        GattsRegCbLinkList_FreeLinkList(pGattsLinkList);
        pGattsLinkList = NULL;
    }
    return RPCR_OK;
}


#if 0
static INT32 _hndlr_x_mtkapi_bt_multi_gatts_get_connect_result_info(RPC_ID_T     t_rpc_id,
                                                                             const CHAR*  ps_cb_type,
                                                                             UINT32       ui4_num_args,
                                                                             ARG_DESC_T*  pt_args,
                                                                             ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]bt_gatts_get_connect_result_info, arg_1 = %p\n", pt_args[0].u.pv_desc);
    if (ui4_num_args != 1)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = RPCR_OK;
    x_mtkapi_bt_multi_gatts_get_connect_result_info(pt_args[0].u.pv_desc);
    return RPCR_OK;
}

static INT32 _hndlr_x_mtkapi_bt_multi_gatts_get_disconnect_result_info(RPC_ID_T     t_rpc_id,
                                                                                 const CHAR*  ps_cb_type,
                                                                                 UINT32       ui4_num_args,
                                                                                 ARG_DESC_T*  pt_args,
                                                                                 ARG_DESC_T*  pt_return)
{
    BT_RH_LOG("[_hndlr_]bt_gatts_get_disconnect_result_info, arg_1 = %p\n", pt_args[0].u.pv_desc);
    if (ui4_num_args != 1)
    {
        BT_RH_LOG("Invalid ARGS: %d\n", ui4_num_args);
        return RPCR_INV_ARGS;
    }
    pt_return->e_type   = ARG_TYPE_INT32;
    pt_return->u.i4_arg = RPCR_OK;
    x_mtkapi_bt_multi_gatts_get_disconnect_result_info(pt_args[0].u.pv_desc);
    return RPCR_OK;
}
#endif

INT32 c_rpc_reg_mtk_bt_service_multi_gatts_op_hndlrs(VOID)
{
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_register_callback);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_register_server);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_unregister_server);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_connect);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_disconnect);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_add_service);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_add_included_service);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_add_char);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_add_desc);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_start_service);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_stop_service);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_delete_service);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_send_indication);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_send_response);
    RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_unregister_callback);
    //RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_get_connect_result_info);
    //RPC_REG_OP_HNDLR(x_mtkapi_bt_multi_gatts_get_disconnect_result_info);
    return RPCR_OK;
}


