/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE charGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

#ifndef _MTK_BT_SERVICE_MULTI_GATTC_WRAPPER_H_
#define _MTK_BT_SERVICE_MULTI_GATTC_WRAPPER_H_

#include "u_rpcipc_types.h"
#include "u_bt_mw_gattc.h"

#ifdef  __cplusplus
extern "C" {
#endif

typedef VOID (*mtkrpcapi_BtAppMultiGATTCEventCbk)(BT_GATTC_EVENT_T bt_gatt_event, BT_GATTC_CONNECT_STATE_OR_RSSI_T *bt_gattc_connect_state_or_rssi, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCRegClientCbk)(BT_GATTC_REG_CLIENT_T *pt_reg_client_result, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCScanCbk)(BT_GATTC_SCAN_RST_T *pt_scan_result, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCGetGattDbCbk)(BT_GATTC_GET_GATT_DB_T *pt_get_gatt_db_result, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCGetRegNotiCbk)(BT_GATTC_GET_REG_NOTI_RST_T *pt_get_reg_noti_result, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCNotifyCbk)(BT_GATTC_GET_NOTIFY_T *pt_notify, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCReadCharCbk)(BT_GATTC_READ_CHAR_RST_T *pt_read_char, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCWriteCharCbk)(BT_GATTC_WRITE_CHAR_RST_T *pt_write_char, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCReadDescCbk)(BT_GATTC_READ_DESCR_RST_T *pt_read_desc, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCWriteDescCbk)(BT_GATTC_WRITE_DESCR_RST_T *pt_write_desc, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTScanFilterParamCbk)(BT_GATTC_SCAN_FILTER_PARAM_T *pt_scan_filter_param, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTScanFilterStatusCbk)(BT_GATTC_SCAN_FILTER_STATUS_T *pt_scan_filter_status, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTScanFilterCfgCbk)(BT_GATTC_SCAN_FILTER_CFG_T *pt_scan_filter_cfg, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCAdvEnableCbk)(BT_GATTC_ADV_ENABLED_T *pt_adv_enabled, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCConfigMtuCbk)(BT_GATTC_MTU_RST_T *pt_config_mtu_result, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCPhyUpdatedCbk)(BT_GATTC_PHY_UPDATED_T *pt_phy_updated, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTCGetAdvRpaCbk)(BT_GATTC_ADV_RPA_T *pt_adv_rpa, void* pv_tag);

typedef struct
{
    mtkrpcapi_BtAppMultiGATTCEventCbk bt_gattc_event_cb;
    mtkrpcapi_BtAppMultiGATTCRegClientCbk bt_gattc_reg_client_cb;
    mtkrpcapi_BtAppMultiGATTCScanCbk bt_gattc_scan_cb;
    mtkrpcapi_BtAppMultiGATTCGetGattDbCbk bt_gattc_get_gatt_db_cb;
    mtkrpcapi_BtAppMultiGATTCGetRegNotiCbk bt_gattc_get_reg_noti_cb;
    mtkrpcapi_BtAppMultiGATTCNotifyCbk bt_gattc_notify_cb;
    mtkrpcapi_BtAppMultiGATTCReadCharCbk bt_gattc_read_char_cb;
    mtkrpcapi_BtAppMultiGATTCWriteCharCbk bt_gattc_write_char_cb;
    mtkrpcapi_BtAppMultiGATTCReadDescCbk bt_gattc_read_desc_cb;
    mtkrpcapi_BtAppMultiGATTCWriteDescCbk bt_gattc_write_desc_cb;
    mtkrpcapi_BtAppMultiGATTScanFilterParamCbk bt_gattc_scan_filter_param_cb;
    mtkrpcapi_BtAppMultiGATTScanFilterStatusCbk bt_gattc_scan_filter_status_cb;
    mtkrpcapi_BtAppMultiGATTScanFilterCfgCbk bt_gattc_scan_filter_cfg_cb;
    mtkrpcapi_BtAppMultiGATTCAdvEnableCbk bt_gattc_adv_enable_cb;
    mtkrpcapi_BtAppMultiGATTCConfigMtuCbk bt_gattc_config_mtu_cb;
    mtkrpcapi_BtAppMultiGATTCPhyUpdatedCbk bt_gattc_phy_updated_cb;
    mtkrpcapi_BtAppMultiGATTCAdvEnableCbk bt_gattc_peri_adv_enable_cb;
    mtkrpcapi_BtAppMultiGATTCGetAdvRpaCbk bt_gattc_get_adv_rpa_cb;
}MTKRPCAPI_BT_APP_MULTI_GATTC_CB_FUNC_T;

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_base_init
** Description      1.Register GATT client app callback functions to bt mw.
**                  2.User should call this API after BT power on, and before call any other GATT APIs.
**                  3.Synchronize return.
** Parameters       [in]func: GATT client app callback functions structure
**                  [in]pv_tag: Reserved for third party app to use this parameter to
**                              get the other needed information from mw
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_base_init(CHAR * app_uuid,
                                                      MTKRPCAPI_BT_APP_MULTI_GATTC_CB_FUNC_T *func,
                                                      void* pv_tag);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_register_app
** Description      1.Register a GATT client application to bt stack
**                  2.User should call this API after a_mtkapi_bt_gattc_base_init,
**                    and before call any other GATT Client APIs.
**                  3.Return via callback function: bt_gatt_reg_client_cb.
** Parameters       [in]app_uuid: Bluetooth 16bit, or 32bit, or 128bit UUID.
**                               e.g. "aaaa", or "aaaaaaaa", or "49557E51-D815-11E4-8830-0800200C9A66"
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_register_app(CHAR * app_uuid);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_unregister_app
** Description      1.Unregister a GATT client application to bt stack.
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app and after all GATT operation completed.
**                  3.No callback function return to bt mw and app.
** Parameters       [in]client_if: registered AP identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_unregister_app(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan
** Description      1.Start LE device scanning using ipc/rpc.
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app.
**                  3.Return via callback function: bt_gatt_scan_cb.
** Parameters       None
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_stop_scan
** Description      1.Stop LE device scanning.
**                  2.User should call this API after a_mtkapi_bt_gattc_scan.
**                  3.No callback function return to bt mw and app.
** Parameters       None
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_stop_scan(INT32 client_if);
extern INT32 a_mtkapi_bt_multi_gattc_unregister_callback(CHAR * app_uuid);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_open
** Description      1.Create a connection to a remote LE or dual-mode device.
**                  2.User should call this API after a_mtkapi_bt_gattc_stop_scan,
**                    should know the remote device bluetooth address.
**                  3.Return via callback function: bt_gatt_event_cb with event type = BT_GATT_CONNECT.
**                    User could get the connected information using a_mtkapi_bt_gattc_get_connect_result_info.
** Parameters       [in]client_if: registered app identifier
**                  [in]bt_addr: remote device bluetooth address
**                  [in]is_direct: is direct connection or background connection
**                  [in]transport: transport type:(0: auto, 1: BREDR, 2: LE)
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_open(INT32 client_if, CHAR *bt_addr,
                                            UINT8 is_direct, INT32 transport);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_close
** Description      1.Disconnect a remote device.
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.Return via callback function: bt_gatt_event_cb with event type=BT_GATT_DISCONNECT,
**                    User could get the disconnected information using a_mtkapi_bt_gattc_get_disconnect_result_info.
** Parameters       [in]client_if: registered app identifier
**                  [in]bt_addr: remote device bluetooth address
**                  [in]conn_id: established connection id
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_close(INT32 client_if, CHAR *bt_addr,
                                             INT32 conn_id);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_listen (Not supported yet)
** Description      1.Start advertisements to listen for incoming connections.
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app.
**                  3.No callback function return to app.
** Parameters       [in]client_if: registered app identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_listen(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_refresh (Not supported yet)
** Description      1.Clear the attribute cache for a given device and rediscover attribute for a given device
**                  2.User should call this API after a_mtkapi_bt_gattc_open, or
**                    after service add/remove occurred on the remote device.
**                  3.No callback function return to bt mw and app.
** Parameters       [in]client_if: registered app identifier
**                  [in]bt_addr: remote device bluetooth address
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_refresh(INT32 client_if, CHAR *bt_addr);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_search_service (Not supported yet)
** Description      1.Enumerate all GATT services on a connected device. The result can be filtered for a given UUID.
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.No callback function return to app, only callback return to bt mw: bluetooth_gattc_search_complete_cbk.
** Parameters       [in]conn_id: established connection id
**                  [in]uuid: 16bit, or 32bit, or 128bit service uuid
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_search_service(INT32 conn_id, CHAR *uuid);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_get_gatt_db (Not supported yet)
** Description      1.Enumerate all GATT services, included services, characteristics, descriptors for a given service
**                  2.User should call this API after a_mtkapi_bt_gattc_open
**                  3.Return via callback function: bt_gatt_get_gatt_db_cb.
** Parameters       [in]conn_id: established connection id
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_get_gatt_db(INT32 conn_id);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_read_char (Not supported yet)
** Description      1.Read a characteristic on a remote device.
**                  2.User should call this API after a_mtkapi_bt_gattc_get_gatt_db.
**                  3.Return via callback function: bt_gatt_read_char_cb.
** Parameters       [in]conn_id: established connection id
**                  [in]char_handle: reading char handle
**                  [in]auth_req: authentication requirement for reading char specified by char_handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_read_char(INT32 conn_id, INT32 char_handle,
                                                   INT32 auth_req);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_read_descr (Not supported yet)
** Description      1.Read the descriptor for a given characteristic
**                  2.User should call this API after a_mtkapi_bt_gattc_get_gatt_db.
**                  3.Return via callback function: bt_gatt_read_desc_cb.
** Parameters       [in]conn_id: established connection id
**                  [in]descr_handle: reading descriptor handle
**                  [in]auth_req: authentication requirement for reading descriptor specified by handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_read_descr(INT32 conn_id, INT32 descr_handle,
                                                    INT32 auth_req);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_write_char (Not supported yet)
** Description      1.Write a remote descriptor for a given characteristic
**                  2.User should call this API after a_mtkapi_bt_gattc_get_gatt_db.
**                  3.Return via callback function: bt_gatt_write_desc_cb.
** Parameters       [in]conn_id: established connection id
**                  [in]char_handle: writing characteristic handle
**                  [in]write_type: 1: write no response, 2: write with response, 3:WRITE_TYPE_PREPARE
**                  [in]len: write characteristic value length
**                  [in]auth_req: authentication request flag
**                  [in]value: write characteristic value
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_write_char(INT32 conn_id, INT32 char_handle,
                                                   INT32 write_type, INT32 len,
                                                   INT32 auth_req, CHAR *value);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_write_descr (Not supported yet)
** Description      1.Write a remote descriptor for a given characteristic.
**                  2.User should call this API after a_mtkapi_bt_gattc_get_gatt_db.
**                  3.Return via callback function: bt_gatt_write_desc_cb.
** Parameters       [in]conn_id: established connection id
**                  [in]descr_handle: writing descriptor handle
**                  [in]write_type: 1: write no response, 2: write with response, 3:WRITE_TYPE_PREPARE
**                  [in]len: write descriptor value length
**                  [in]auth_req: authentication request flag
**                  [in]value: write descriptor value
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_write_descr(INT32 conn_id, INT32 descr_handle,
                                                     INT32 write_type, INT32 len,
                                                     INT32 auth_req, CHAR *value);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_execute_write (Not supported yet)
** Description      1.Execute a prepared write operation
**                  2.User should call this API after calling a_mtkapi_bt_gattc_write_descr or
**                    a_mtkapi_bt_gattc_write_char with write_type = 3:WRITE_TYPE_PREPARE.
**                  3.No callback function return to app, only callback function return to bt mw:
**                    bluetooth_gattc_execute_write_cbk.
** Parameters       [in]conn_id: established connection id
**                  [in]execute: 1:execute, 0: cancel execute
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_execute_write(INT32 conn_id, INT32 execute);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_reg_noti (Not supported yet)
** Description      1.Register to receive notifications or indications for a given characteristic
**                  2.User should call this API after a_mtkapi_bt_gattc_get_gatt_db.
**                  3.Return via callback function: bt_gatt_get_reg_noti_cb.
** Parameters       [in]client_if: registered AP identifier
**                  [in]bt_addr: bluetooth address of discovered device
**                  [in]char_handle: characteristic handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_reg_noti(INT32 client_if, CHAR *bt_addr,
                                                INT32 char_handle);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_dereg_noti (Not supported yet)
** Description      1.Deregister a previous request for notifications or indications
**                  2.User should call this API after a_mtkapi_bt_gattc_reg_noti.
**                  3.Return via callback function: bt_gatt_get_reg_noti_cb.
** Parameters       [in]client_if: registered AP identifier
**                  [in]bt_addr: bluetooth address of discovered device
**                  [in]char_handle: characteristic handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_dereg_noti(INT32 client_if, CHAR *bt_addr,
                                                    INT32 char_handle);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_read_rssi (Not supported yet)
** Description      1.Request RSSI for a given remote device
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.Return via callback function: bt_gatt_event_cb with event type = BT_GATT_GET_RSSI_DONE,
**                    User could get the rssi information using a_mtkapi_bt_gatts_read_rssi_result_info.
** Parameters       [in]client_if: registered AP identifier
**                  [in]bt_addr: bluetooth address of discovered device
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_read_rssi(INT32 client_if, CHAR *bt_addr);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan_filter_param_setup (Not supported yet)
** Description      1.Setup scan filter params
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app.
**                  3.Return via callback function        : bt_gatt_scan_filter_param_cb.
** Parameters       [in]scan_filt_param.client_if         : registered AP identifier
**                  [in]scan_filt_param.action            : 0: add   1: delete  2: clear
**                  [in]scan_filt_param.filt_index        : filter index
**                  [in]scan_filt_param.feat_seln         : filter selection number,
**                                                          Bit 0: Set to enable Broadcast Address filter
**                                                          Bit 1: Set to enable Service Data Change filter
**                                                          Bit 2: Set to enable Service UUID check
**                                                          Bit 3: Set to enable Service Solicitation UUID check
**                                                          Bit 4: Set to enable Local Name check
**                                                          Bit 5: Set to enable Manufacturer Data Check
**                                                          Bit 6: Set to enable Service Data Check
**                  [in]scan_filt_param.list_logic_type   : the logic to list for each filter field.
**                  [in]scan_filt_param.filt_logic_type   : the logic to filter for each filter field. , it only
**                                                          applicable for (Bit 3~Bit 6) four fields of APCF_Feature_Selection
**                  [in]scan_filt_param.rssi_high_thres   : upper threshold of the rssi value
**                  [in]scan_filt_param.rssi_low_thres    : lower threshold of the rssi value
**                  [in]scan_filt_param.dely_mode         : 0: immediate    1:on_found   2: batched
**                  [in]scan_filt_param.found_timeout     : time for firmware to linger and collect additional advertisements
**                                                          before reporting, valid only if dely_mode is on _found.
**                  [in]scan_filt_param.lost_timeout      : If an advertisement, after being found, is not seen contiguously
**                                                          for the lost_timeout period, it will be reported lost.
**                                                          Valid only if dely_mode is on _found.
**                  [in]scan_filt_param.found_timeout_cnt : count of found timeout
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan_filter_param_setup(BT_GATTC_FILT_PARAM_SETUP_T *scan_filt_param);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan_filter_enable (Not supported yet)
** Description      1.Enable scan filter feature
**                  2.User should call this API after a_mtkapi_bt_gattc_scan_filter_add_remove.
**                  3.Return via callback function: bt_gatt_scan_filter_status_cb.
** Parameters       [in]client_if: registered AP identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan_filter_enable(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan_filter_disable (Not supported yet)
** Description      1.Disable scan filter feature
**                  2.User should call this API after a_mtkapi_bt_gattc_scan_filter_enable.
**                  3.Return via callback function: bt_gatt_scan_filter_status_cb.
** Parameters       [in]client_if: registered AP identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan_filter_disable(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan_filter_add_remove (Not supported yet)
** Description      1.Configure a scan filter condition
**                  2.User should call this API after a_mtkapi_bt_gattc_scan_filter_param_setup.
**                  3.Return via callback function: bt_gatt_scan_filter_cfg_cb.
** Parameters       [in]client_if       : registered AP identifier
**                  [in]action: 0       : add    1: delete  2: clear
**                  [in]filt_type       : 0: addr    1: service data   2: service uuid
                                          3: solicited service uuid    4: local name
**                                        5: manufacture data          6: service data pattern
**                  [in]filt_index      : filter index
**                  [in]company_id      : company id
**                  [in]company_id_mask : the mask of company id
**                  [in]p_uuid          : bluetooth 128-bit UUID
**                  [in]p_uuid_mask     : the mask of Bluetooth 128-bit UUID
**                  [in]bd_addr         : bluetooth device address
**                  [in]addr_type       : address type
**                  [in]data_len        : length of value
**                  [in]p_data          : value
**                  [in]mask_len        : the length of mask
**                  [in]p_mask          : mask
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan_filter_add_remove(INT32 client_if,
                                                                    INT32 action,
                                                                    INT32 filt_type,
                                                                    INT32 filt_index,
                                                                    INT32 company_id,
                                                                    INT32 company_id_mask,
                                                                    const CHAR *p_uuid,
                                                                    const CHAR *p_uuid_mask,
                                                                    const CHAR *bd_addr,
                                                                    CHAR addr_type,
                                                                    INT32 data_len,
                                                                    CHAR *p_data,
                                                                    INT32 mask_len,
                                                                    CHAR *p_mask);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_scan_filter_clear (Not supported yet)
** Description      1.Clear all scan filter conditions for specific filter index
**                  2.User should call this API after a_mtkapi_bt_gattc_scan_filter_add_remove,
**                    or after a_mtkapi_bt_gattc_scan_filter_enable.
**                  3.Return via callback function: bt_gatt_scan_filter_cfg_cb.
** Parameters       [in]client_if: registered AP identifier
**                  [in]filt_index: filter index
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_scan_filter_clear(INT32 client_if, INT32 filt_index);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_get_device_type (Not supported yet)
** Description      1.Determine the type of the remote device  using ipc/rpc(LE, BR/EDR or Dual-mode).
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.Synchronized return.
** Parameters       [in]bd_addr: bluetooth device address
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_get_device_type(CHAR *bd_addr);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_configure_mtu (Not supported yet)
** Description      1.Configure the MTU for a given connection
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.No callback function to app, only callback function return
**                    to bt mw: linuxbt_gattc_configure_mtu_callback.
** Parameters       [in]conn_id: identifier of connection
**                  [in]mtu: maximum transmit unit
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_configure_mtu(INT32 conn_id, INT32 mtu);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_conn_parameter_update (Not supported yet)
** Description      1.Request a connection parameter update
**                  2.User should call this API after a_mtkapi_bt_gattc_open.
**                  3.No callback function to btmw and app.
** Parameters       [in]bt_addr: bluetooth address of discovered device
**                  [in]min_interval: the minimum allowed connection interval(N*0.625ms)(0x20~0x400)(20ms~10.24s)
**                  [in]max_interval: the maximum allowed connection interval(N*0.625ms)(0x20~0x400)(20ms~10.24s)
**                  [in]latency: the maximum allowed connection latency
**                  [in]timeout: define the link supervision timeout
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_conn_parameter_update(CHAR *bt_addr,
                                                                    INT32 min_interval,
                                                                    INT32 max_interval,
                                                                    INT32 latency,
                                                                    INT32 timeout);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_set_scan_parameters (Not supported yet)
** Description      1.Sets the LE scan interval and window in units of N*0.625 msec
**                  2.User should call this API after a_mtkapi_bt_gattc_multi_adv_enable.
**                  3.No callback function to app, only callback function return to bt mw:
**                    linuxbt_gattc_scan_parameter_setup_completed_callback.
** Parameters       [in]client_if     : registered AP identifier
**                  [in]scan_interval : how frequently the controller should scan
**                  [in]scan_window   : how long the controller should scan
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_set_scan_parameters(INT32 client_if,
                                                                 INT32 scan_interval,
                                                                 INT32 scan_window);

extern INT32 a_mtkapi_bt_multi_gattc_start_advertising_set(INT32 client_if,
                            BT_GATTC_ADVERTISING_PARAMS_T *p_adv_param,
                            BT_GATTC_ADVERTISING_DATA_T   *P_adv_data,
                            BT_GATTC_ADVERTISING_DATA_T   *p_adv_scan_rsp_data,
                            BT_GATTC_PERI_ADV_PERIODIC_PARAMS_T *p_adv_peri_param,
                            BT_GATTC_ADVERTISING_DATA_T *p_adv_peri_adv_data,
                            UINT16 duration,
                            UINT8 maxExtAdvEvents);

extern INT32 a_mtkapi_bt_multi_gattc_advertising_set_param(INT32 client_if,
                                            BT_GATTC_ADVERTISING_PARAMS_T *p_adv_param);

extern INT32 a_mtkapi_bt_multi_gattc_advertising_set_peri_param(INT32 client_if,
                                          BT_GATTC_PERI_ADV_PERIODIC_PARAMS_T *p_peri_param);

extern INT32 a_mtkapi_bt_multi_gattc_advertising_peri_enable(INT32 client_if, UINT8 enable);

extern INT32 a_mtkapi_bt_multi_gattc_advertising_set_data(INT32 client_if, UINT8 adv_data_type,
                                        BT_GATTC_ADVERTISING_DATA_T *p_adv_data);

extern INT32 a_mtkapi_bt_multi_gattc_set_disc_mode(INT32 client_if, INT32 disc_mode);

extern INT32 a_mtkapi_bt_multi_gattc_stop_advertising_set(INT32 client_if);
/*******************************************************************************
** Function         a_mtkapi_bt_gattc_batchscan_cfg_storage (Not supported yet)
** Description      1.Configure the batchscan storage
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app.
**                  3.No callback function to app, only callback function return to bt mw:
**                    linuxbt_gattc_batchscan_cfg_storage_callback.
** Parameters       [in]client_if: registered AP identifier
**                  [in]batch_scan_full_max: full max storage space(in %) for batch scan
**                  [in]batch_scan_trunc_max: truncate max storage space(in %)  for batch scan
**                  [in]batch_scan_notify_threshold: notify threshold value (in %)  for batch scan storage
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_batchscan_cfg_storage(INT32 client_if,
                                                                   INT32 batch_scan_full_max,
                                                                   INT32 batch_scan_trunc_max,
                                                                   INT32 batch_scan_notify_threshold);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_batchscan_enb_batch_scan (Not supported yet)
** Description      1.Enable batchscan
**                  2.User should call this API after a_mtkapi_bt_gattc_batchscan_cfg_storage.
**                  3.No callback function to app, only callback function return to bt mw:
**                    linuxbt_gattc_batchscan_cfg_enable_disable_callback.
** Parameters       [in]client_if     : registered AP identifier
**                  [in]scan_mode     : scan mode, disable: 0x00, truncate mode enable: 0x01,
**                                                 full mode enable: 0x02,
**                                                 truncate and full mode enable: 0x03
**                  [in]scan_interval : how frequently to scan
**                  [in]scan_window   : how long to scan
**                  [in]addr_type     : address type, public:0x00, random: 0x01
**                  [in]discard_rule  : discard rule, discard oldest advertisement:0,
**                                      discard advertisement with weakest rssi: 1
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_batchscan_enb_batch_scan(INT32 client_if,
                                                                        INT32 scan_mode,
                                                                        INT32 scan_interval,
                                                                        INT32 scan_window,
                                                                        INT32 addr_type,
                                                                        INT32 discard_rule);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_batchscan_dis_batch_scan (Not supported yet)
** Description      1.Disable batchscan
**                  2.User should call this API after a_mtkapi_bt_gattc_batchscan_enb_batch_scan.
**                  3.No callback function to app, only callback function return to bt mw:
**                    linuxbt_gattc_batchscan_cfg_enable_disable_callback.
** Parameters       [in]client_if: registered AP identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_batchscan_dis_batch_scan(INT32 client_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_batchscan_read_reports (Not supported yet)
** Description      1.Read out batchscan reports
**                  2.User should call this API after a_mtkapi_bt_gattc_batchscan_enb_batch_scan.
**                  3.No callback function to app, only callback function return to bt mw:
**                    linuxbt_gattc_batchscan_reports_callback.
** Parameters       [in]client_if: registered AP identifier
**                  [in]scan_mode: scan mode, truncate mode: 1,   full mode: 2
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_batchscan_read_reports(INT32 client_if,
                                                                    INT32 scan_mode);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_set_local_le_name (Not supported yet)
** Description      1.GATT Client to set local le name
**                  2.User should call this API after a_mtkapi_bt_gattc_register_app.
**                  3.No callback function to bt mw and app.
** Parameters       [in]client_if: registered AP identifier
**                  [in]le_name  : local device le name
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gattc_set_local_le_name(INT32 client_if,
                                                             CHAR *le_name);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_get_connect_result_info (Not supported yet)
** Description      1.GATT client get connection result information
**                  2.User should call this API after receive the callback function:
**                    bt_gatt_event_cb with event type = BT_GATT_CONNECT.
**                  3.Synchronize return.
** Parameters       [in]connect_rst_info: connection result information
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern VOID a_mtkapi_bt_multi_gattc_get_connect_result_info(BT_GATTC_CONNECT_RST_T *connect_rst_info);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_get_disconnect_result_info (Not supported yet)
** Description      1.GATT client get disconnection result information
**                  2.User should call this API after receive the callback function:
**                    bt_gatt_event_cb with event type = BT_GATT_DISCONNECT.
**                  3.Synchronize return.
** Parameters       [in]disconnect_rst_info: disconnection result information
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern VOID a_mtkapi_bt_multi_gattc_get_disconnect_result_info(BT_GATTC_CONNECT_RST_T *disconnect_rst_info);

/*******************************************************************************
** Function         a_mtkapi_bt_gattc_read_rssi_result_info (Not supported yet)
** Description      1.Get read rssi result information
**                  2.User should call this API after receive the callback function:
**                    bt_gatt_event_cb with event type = BT_GATT_GET_RSSI_DONE.
**                  3.Synchronize return.
** Parameters       [in]get_remote_rssi_info: received signal strength indicator result information
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern VOID a_mtkapi_bt_multi_gattc_read_rssi_result_info(BT_GATTC_GET_REMOTE_RSSI_T *get_remote_rssi_info);
extern INT32 a_mtkapi_bt_multi_gattc_set_preferred_phy(CHAR *bt_addr, UINT8 tx_phy,
                                        UINT8 rx_phy, UINT16 phy_options);
extern INT32 a_mtkapi_bt_multi_gattc_read_phy(INT32 client_if, CHAR *bt_addr);
extern INT32 a_mtkapi_bt_multi_gattc_get_local_adv_rpa(INT32 client_if);
extern INT32 c_rpc_reg_mtk_bt_service_multi_gattc_cb_hndlrs(VOID);

#ifdef  __cplusplus
}
#endif
#endif
