/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016-2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE charGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

#ifndef _MTK_BT_SERVICE_MULTI_GATTS_WRAPPER_H_
#define _MTK_BT_SERVICE_MULTI_GATTS_WRAPPER_H_

#include "u_rpcipc_types.h"
#include "u_bt_mw_gatts.h"

#ifdef  __cplusplus
extern "C" {
#endif

typedef VOID (*mtkrpcapi_BtAppMultiGATTSEventCbk)(BT_GATTS_EVENT_T bt_gatts_event, BT_GATTS_CONNECT_RST_T *bt_gatts_connect, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSRegServerCbk)(BT_GATTS_REG_SERVER_RST_T *bt_gatts_reg_server, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSAddSrvcCbk)(BT_GATTS_ADD_SRVC_RST_T *bt_gatts_add_srvc, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSAddInclCbk)(BT_GATTS_ADD_INCL_RST_T *bt_gatts_add_incl, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSAddCharCbk)(BT_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSAddDescCbk)(BT_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSOpSrvcCbk)(BT_GATTS_SRVC_OP_TYPE_T op_type, BT_GATTS_SRVC_RST_T *bt_gatts_srvc, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSReqReadCbk)(BT_GATTS_REQ_READ_RST_T *bt_gatts_read, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSReqWriteCbk)(BT_GATTS_REQ_WRITE_RST_T *bt_gatts_write, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSIndSentCbk)(INT32 conn_id, INT32 status, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSConfigMtuCbk)(BT_GATTS_CONFIG_MTU_RST_T *bt_gatts_config_mtu, void* pv_tag);
typedef VOID (*mtkrpcapi_BtAppMultiGATTSExecWriteCbk)(BT_GATTS_EXEC_WRITE_RST_T *bt_gatts_exec_write, void* pv_tag);

/******************************************************************************/
/* GATTS Structs                                                              */
/******************************************************************************/
typedef struct
{
    mtkrpcapi_BtAppMultiGATTSEventCbk bt_multi_gatts_event_cb;
    mtkrpcapi_BtAppMultiGATTSRegServerCbk bt_gatts_reg_server_cb;
    mtkrpcapi_BtAppMultiGATTSAddSrvcCbk bt_gatts_add_srvc_cb;
    mtkrpcapi_BtAppMultiGATTSAddInclCbk bt_gatts_add_incl_cb;
    mtkrpcapi_BtAppMultiGATTSAddCharCbk bt_gatts_add_char_cb;
    mtkrpcapi_BtAppMultiGATTSAddDescCbk bt_gatts_add_desc_cb;
    mtkrpcapi_BtAppMultiGATTSOpSrvcCbk bt_gatts_op_srvc_cb;
    mtkrpcapi_BtAppMultiGATTSReqReadCbk bt_gatts_req_read_cb;
    mtkrpcapi_BtAppMultiGATTSReqWriteCbk bt_gatts_req_write_cb;
    mtkrpcapi_BtAppMultiGATTSIndSentCbk bt_gatts_ind_sent_cb;
    #if !defined(MTK_LINUX_C4A_BLE_SETUP)
    mtkrpcapi_BtAppMultiGATTSConfigMtuCbk bt_gatts_config_mtu_cb;
    #endif
    mtkrpcapi_BtAppMultiGATTSExecWriteCbk bt_gatts_exec_write_cb;
}MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T;

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_base_init
** Description      Register GATT server app callback functions to bt mw.
**                  Synchronize return.
** Parameters       [in]func: GATT server app callback functions structur
**                  [in]pv_tag: Reserved for third party app to use this parameter to
**                              get the other needed information from mw
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_base_init(char *app_uuid,
                                                      MTKRPCAPI_BT_APP_MULTI_GATTS_CB_FUNC_T *func,
                                                      void* pv_tag);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_register_server
** Description      Register the GATT server application to bt stack.
**                  Return via callback function: bt_gatts_reg_server_cb
** Parameters       [in]app_uuid: Bluetooth 16bit, or 32bit, or 128bit UUID.
**                      ex, e.g. "aaaa", or "aaaaaaaa", or  "49557E51-D815-11E4-8830-0800200C9A66"
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_register_server(CHAR * app_uuid);

extern INT32 a_mtkapi_bt_multi_gatts_unregister_callback(CHAR * app_uuid);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_unregister_server
** Description      Unregister the GATT server application from bt stack
**                  No callback function return to bt mw and app.
** Parameters       [in]server_if: registered AP identifier
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_unregister_server(INT32 server_if);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_open
** Description      Create a connection to a remote peripheral.
**                  User should call this API after a_mtkapi_bt_gatts_register_server.
**                  Return via callback function: bt_gatts_event_cb with event type=BT_GATTS_CONNECT,
**                  User could get the connected information using a_mtkapi_bt_gatts_get_connect_result_info.
** Parameters       [in]server_if: registered AP identifier
**                  [in]bt_addr: BT address of remote peripheral.
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_open(INT32 server_if, CHAR *bt_addr,
                                            UINT8 is_direct, INT32 transport);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_close
** Description      Disconnect an established connection.
**                  User should call this API after a_mtkapi_bt_gatts_open.
**                  Return via callback function: bt_gatts_event_cb with event type=BT_GATTS_DISCONNECT,
**                  User could get the disconnected information using a_mtkapi_bt_gatts_get_disconnect_result_info.
** Parameters       [in]server_if: registered AP identifier
**                  [in]bt_addr: BT address of remote peripheral.
**                  [in]conn_id: established connection id
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_close(INT32 server_if, CHAR *bt_addr,
                                             INT32 conn_id);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_add_service
** Description      Create a new service and save it in the database of bt stack
**                  User should call this API after a_mtkapi_bt_gatts_register_server
**                  For service_uuid, refer to https://www.bluetooth.com/specifications/gatt/services/
**                  Return via callback function: bt_gatts_add_srvc_cb.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_uuid: 16bit, or 32 bit, or 128bit service uuid.
**                      e.g. "aaaa", or "aaaaaaaa", or "49557E51-D815-11E4-8830-0800200C9A66"
**                  [in]is_primary: is primary service or not
**                  [in]number: handle number
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_add_service(INT32 server_if,
                                                     CHAR *service_uuid,
                                                     UINT8 is_primary,
                                                     INT32 number);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_add_included_service
** Description      Assign an included service to the parent service.
**                  User should call this API after a_mtkapi_bt_gatts_add_service.
**                  Return via callback function: bt_gatts_add_incl_cb.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
**                  [in]include_handle: include service handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_add_included_service(INT32 server_if,
                                                                 INT32 service_handle,
                                                                 INT32 included_handle);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_add_char
** Description      Add a characteristic to a server.
**                  User should call this API after a_mtkapi_bt_gatts_add_service.
**                  Return via callback function: bt_gatts_add_char_cb.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
**                  [in]uuid: characteristic uuid
**                      e.g. "aaaa", or "aaaaaaaa", or "49557E51-D815-11E4-8830-0800200C9A66"
**                  [in]properties: characteristic properties
**                      e.g. read(0x02), write without response(0x04), write(0x08), notify(0x10), indicate(0x20)
**                  [in]permissions: access characteristic permissions
**                      e.g. BT_GATTS_REC_PERM_READABLE
**                           BT_GATTS_REC_PERM_WRITABLE
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_add_char(INT32 server_if,
                                                  INT32 service_handle,
                                                  CHAR *uuid,
                                                  INT32 properties,
                                                  INT32 permissions);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_add_desc
** Description      Add a descriptor to a given service.
**                  User should call this API after a_mtkapi_bt_gatts_add_char.
**                  Return via callback function: bt_gatts_add_desc_cb.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
**                  [in]uuid: characteristic uuid
**                      e.g. "aaaa", or "aaaaaaaa", or "49557E51-D815-11E4-8830-0800200C9A66"
**                  [in]permissions: access characteristic permissions
**                      e.g. BT_GATTS_REC_PERM_READABLE
**                           BT_GATTS_REC_PERM_WRITABLE
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_add_desc(INT32 server_if,
                                                  INT32 service_handle,
                                                  CHAR *uuid,
                                                  INT32 permissions);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_start_service
** Description      Start a local service.
**                  User should call this API after a_mtkapi_bt_gatts_add_service,
**                  or after a_mtkapi_bt_gatts_add_char, or after a_mtkapi_bt_gatts_add_desc.
**                  Return via callback function: bt_gatts_op_srvc_cb with op type = BT_GATTS_START_SRVC.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
**                  [in]transport: transport type:(0 : auto, 1 : BREDR, 2 : LE)
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_start_service(INT32 server_if,
                                                      INT32 service_handle,
                                                      INT32 transport);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_stop_service
** Description      Stop a local service.
**                  User should call this API after a_mtkapi_bt_gatts_start_service.
**                  Return via callback function: bt_gatts_op_srvc_cb with op type = BT_GATTS_STOP_SRVC
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_stop_service(INT32 server_if,
                                                      INT32 service_handle);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_stop_service
** Description      Delete a local service .
**                  User should call this API after a_mtkapi_bt_gatts_add_service.
**                  Return via callback function: bt_gatts_op_srvc_cb with op type = BT_GATTS_DEL_SRVC.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_delete_service(INT32 server_if,
                                                         INT32 service_handle);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_send_indication
** Description      Send value indication to a remote device
**                  User should call this API after established GATT connection with the remote device.
**                  Return via callback function: bt_gatts_ind_sent_cb.
** Parameters       [in]server_if: registered app identifier
**                  [in]service_handle: added service start handle
**                  [in]cnon_id: connection id
**                  [in]fg_confirm: is need confirmation or not
**                  [in]p_value: send indication value
**                  [in]value_len: send indication value length
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_send_indication(INT32 server_if,
                                                          INT32 attribute_handle,
                                                          INT32 conn_id,
                                                          INT32 fg_confirm,
                                                          CHAR *p_value,
                                                          INT32 value_len);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_send_response
** Description      Send a response to a read/write operation.
**                  User should call this API after receive the read/write request from the remote device.
**                  No callback function return to app.
** Parameters       [in]cnon_id: connection id
**                  [in]trans_id: transaction id
**                  [in]status: send response status
**                  [in]attr_handle: send response handle
**                  [in]p_value: send response value
**                  [in]value_len: send response value length
**                  [in]auth_req: authentication request
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
extern INT32 a_mtkapi_bt_multi_gatts_send_response(INT32 conn_id,
                                                         INT32 trans_id,
                                                         INT32 status,
                                                         INT32 handle,
                                                         CHAR *p_value,
                                                         INT32 value_len,
                                                         INT32 auth_req);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_get_connect_result_info
** Description      Get connection result information.
**                  User should call this API after receive the callback function:
**                  bt_gatts_event_cb with event type = BT_GATTS_CONNECT.
**                  Synchronize return.
** Parameters       [in]connect_rst_info: connection result information
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
//extern VOID a_mtkapi_bt_multi_gatts_get_connect_result_info(BT_GATTS_CONNECT_RST_T *connect_rst_info);

/*******************************************************************************
** Function         a_mtkapi_bt_gatts_get_disconnect_result_info
** Description      Get disconnection result information.
**                  User should call this API after receive the callback function:
**                  bt_gatts_event_cb with event type = BT_GATTS_DISCONNECT.
**                  Synchronize return.
** Parameters       [in]disconnect_rst_info: disconnection result information
** Returns          BT_ERR_STATUS_T
*******************************************************************************/
//extern VOID a_mtkapi_bt_multi_gatts_get_disconnect_result_info(BT_GATTS_CONNECT_RST_T *disconnect_rst_info);
extern INT32 c_rpc_reg_mtk_bt_service_multi_gatts_cb_hndlrs(void);

#ifdef  __cplusplus
}
#endif
#endif
