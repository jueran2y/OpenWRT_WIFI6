#ifndef __BTMW_TEST_CONFIG_H__
#define __BTMW_TEST_CONFIG_H__

/* LSDK vendor config */
#define CONFIG_USER_GATT_APCLI 1

#endif
