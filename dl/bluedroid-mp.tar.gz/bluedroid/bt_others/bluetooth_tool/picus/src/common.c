//---------------------------------------------------------------------------
#include "common.h"

//---------------------------------------------------------------------------
int g_debuglevel = MT_DEBUG_WARN;       // show priority than WARN

//---------------------------------------------------------------------------
void DBGPRINT(int level, const char *format, ...)
{
    if (level > g_debuglevel) {
        // don't print
        return;
    }

    char buf[1024] = "";
    va_list Arg;
    va_start(Arg, format);
    vsnprintf(buf, 300, format, Arg);
    va_end(Arg);
    printf("[picus] %s\n", buf);
    return;
}

//---------------------------------------------------------------------------
