
#ifndef _BT_DBG_CONFIG_SPP_H_
#define _BT_DBG_CONFIG_SPP_H_


enum
{
    SPP_CMD_START = DBG_SPP << MOD_LOCATION & 0xFF000000,

    SPP_CMD_END
};

#endif

