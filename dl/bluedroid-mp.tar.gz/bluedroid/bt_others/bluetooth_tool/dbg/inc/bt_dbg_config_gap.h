
#ifndef _BT_DBG_CONFIG_GAP_H_
#define _BT_DBG_CONFIG_GAP_H_

enum
{
    GAP_CMD_START = DBG_GAP << MOD_LOCATION & 0xFF000000,

    GAP_CMD_VAR,
    GAP_CMD_STR,
//    GAP_CMD_LOCAL_PROPERTY,

    GAP_CMD_END
};

#if defined(BT_RPC_DBG_SERVER)
extern int gap_var_test(int array_index, int offset, char *buff, int length);
extern int gap_str_test(int array_index, int offset, char *buff, int length);
//extern int dbg_gap_get_g_local_property(int array_index, int offset, char *buff, int length);
#endif

#if defined(BT_RPC_DBG_SERVER)
#define GAP_DATA_VAR (gap_var_test)
#endif
#if defined(BT_RPC_DBG_CLIENT)
#define GAP_DATA_VAR (HEAD"GAP"TYPE"VAR"ARRY"8"NAME"gap_demo_var"TAIL)
#endif

#if defined(BT_RPC_DBG_SERVER)
#define GAP_DATA_STR (gap_str_test)
#endif
#if defined(BT_RPC_DBG_CLIENT)
#define GAP_DATA_STR (HEAD"GAP"TYPE"STR"ARRY"16"NAME"gap_demo_str"MEMB"int_demo"MEMB"str_demo"TAIL)
#endif

//#if defined(BT_RPC_DBG_SERVER)
//#define GAP_DATA_LOCAL_PROPERTY (dbg_gap_get_g_local_property)
//#endif
//#if defined(BT_RPC_DBG_CLIENT)
//#define GAP_DATA_LOCAL_PROPERTY (HEAD"GAP"TYPE"STR"ARRY"0"NAME"g_local_property" \
//    MEMB"bdAddr"MEMB"name"MEMB"powered"MEMB"scan_mode"MEMB"disctimeout" \
//    MEMB"uuid_num"MEMB"local_uuids"MEMB"paired_devices.num_devices"MEMB"paired_devices.devices"TAIL)
//#endif

#if defined(BT_RPC_DBG_SERVER) || defined(BT_RPC_DBG_CLIENT)
static SUB_CMD gap_cmd[GAP_CMD_NUM] =
{
    {GAP_CMD_VAR,   GAP_DATA_VAR},
    {GAP_CMD_STR,   GAP_DATA_STR},
//    {GAP_CMD_LOCAL_PROPERTY,   GAP_DATA_LOCAL_PROPERTY},

    {0,   NULL}
};
#endif

#endif

