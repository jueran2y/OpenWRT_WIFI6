/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>

#include "bt_dbg_config.h"
#include "rw_init_mtk_bt_service.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


#define for_each_opt(opt, long, short) while ((opt=getopt_long(argc, argv, short ? short:"+", long, NULL)) != -1)

/**************************************************************************
 *                 G L O B A L   V A R I A B L E S                        *
***************************************************************************/

/**************************************************************************
 *                         F U N C T I O N S                              *
***************************************************************************/

static struct option main_options[] = {
    { "help", 0, 0, 'h' },
    { 0, 0, 0, 0 }
};

static struct option sub_options[] = {
    { "help", 0, 0, 'h' },
    { "read", 0, 0, 'r' },
    { "write", 0, 0, 'w' },
    { "cmd", 1, 0, 'c' },
    { "index", 1, 0, 'i' },
    { "value", 1, 0, 'v' },
    { 0, 0, 0, 0 }
};

static void print_output(char *doc)
{
    int fd = 0, len = 0, location = 0;
    char *data = NULL;
    char *p_doc = NULL, *p_end = NULL;
    char *p_data = NULL;

    fd = open(BT_DBG_R_FILE, O_RDWR | O_CREAT , 0777);
    if (fd < 0)
    {
        printf("%s open bt-dbg-r file failed %d", __func__, fd);
        return;
    }

    len = lseek(fd, 0, SEEK_END);
    data = malloc(len + 1);
    if (NULL == data)
    {
        printf("%s malloc data failed", __func__);
        close(fd);
        return;
    }

    memset(data, 0, len + 1);
    lseek(fd, 0, SEEK_SET);
    read(fd, data, len);
    p_data = data;

    if (NULL != (p_doc = strstr(doc, TYPE"VAR")))
    {
        p_doc = strstr(p_doc, NAME) + 1;
        p_end = strstr(p_doc, TAIL);
        printf("\nThe value of ");
         while (p_doc != p_end)
        {
            printf("%c", *p_doc++);
        }

        p_data++;
        printf(" is %s\n", p_data);
    }
    else if (NULL != (p_doc = strstr(doc, TYPE"STR")))
    {
        p_doc = strstr(p_doc, NAME) + 1;
        p_end = strstr(p_doc, MEMB);
        printf("\nThe members of ");
        while (p_doc != p_end)
        {
            printf("%c", *p_doc++);
        }
        printf("\n");

        p_doc = p_end;
        p_end = strstr(p_doc, TAIL);
        while (p_doc != p_end)
        {
            printf(" ");
            location = 24;
            if (*p_doc == '^')
            {
                p_doc++;
                do
                {
                    printf("%c", *p_doc++);
                    location--;
                }while ((*p_doc != '^') && (p_doc != p_end));
            }

            printf(": ");
            location -= 2;
            while(location > 0)
            {
                printf(" ");
                location--;
            }

            if (*p_data == '&')
            {
                p_data++;
                do
                {
                    printf("%c", *p_data++);
                }while ((*p_data != '&') && (*p_data != '\0'));
            }
        }
        printf("\n");
    }
    else
    {
        printf("Get help info error %d\n", __LINE__);
    }

    free(data);
    close(fd);
    return;
}

static void print_sub_help(int mod)
{
    int i;
    char *ptr_print = NULL, *ptr_end = NULL;
    printf("Usage:\n");
    printf("\tbt-dbg %s --read --cmd <integer> --index <integer>\n", m_cmd[mod].c_mod);
//    printf("\tbt-dbg %s --write --cmd <cmd> --index <index> --value <value>\n", m_cmd[mod].c_mod);
    printf("\t --cmd\n");
    for (i = 0; i < m_cmd[mod].length - 1; i++)
    {
        printf("\t\t %d:\t", i);
        if (NULL != (ptr_print = strstr(m_cmd[mod].s_cmd[i].doc, TYPE"VAR")))
        {
            printf("%s(", "VARIABLE");
        }
        else if (NULL != (ptr_print = strstr(m_cmd[mod].s_cmd[i].doc, TYPE"STR")))
        {
            printf("%s(", "STRUCTRUE");
        }
        else
        {
            printf("parse type error!\n");
            break;
        }

        ptr_print = strstr(ptr_print, ARRY) + 1;
        ptr_end = strstr(ptr_print, NAME);
        while(ptr_print != ptr_end)
        {
            printf("%c", *ptr_print++);
        }
        printf(")\t");

        ptr_print = ptr_end + 1;
        ptr_end = strstr(ptr_print, MEMB);
        if (NULL == ptr_end)
        {
            ptr_end = strstr(ptr_print, TAIL);
        }
        if (NULL == ptr_end)
        {
            printf("parse description error!\n");
            break;
        }

        while(ptr_print != ptr_end)
        {
            printf("%c", *ptr_print++);
        }
        printf("\n");
    }
    printf("\t --index\tOptional. The index of array for read/write array only.\n");
//    printf("\t --value\tThe value for write only.\n");
    printf("Example\n");
    printf("\tbt-dbg %s --read --cmd 0\n", m_cmd[mod].c_mod);
//    printf("\t bt-dbg %s --write --cmd 0 --value 1\n", m_cmd[mod].c_mod);
    return;
}

static void print_help(void)
{
    int i;

    printf("bluetooth debug test - ver %s\n", VERSION);
    printf("Usage:\n"
        "\tbt-dbg <module> <operation> ...... \n");
    printf("modules:\n");
    for (i = 0; m_cmd[i].c_mod; i++) {
        printf("\t%-8s\t%s\n", m_cmd[i].c_mod, m_cmd[i].doc);
    }
    printf("\n"
        "For more information on the usage of each cmd use:\n"
        "\tbt-dbg <module> --help\n\n\n");
}

static int param_check(int m_index, int s_index, int index, int flag, int value_flag)
{
    int i = 0, array_index = 0;
    char s_array_index[16] = {0};
    char *ptr = NULL, *ptr_end = NULL;
    if (s_index >= (m_cmd[m_index].length - 1))
    {
        printf("cmd value %d is invalid, should < %d\n", s_index, m_cmd[m_index].length - 1);
        return -1;
    }

    ptr = strstr(m_cmd[m_index].s_cmd[s_index].doc, ARRY) + 1;
    ptr_end = strstr(ptr, NAME);
    i = 0;
    while (ptr != ptr_end)
    {
        sprintf(s_array_index+i, "%c", *ptr++);
        i++;
    }
    s_array_index[i] = '\0';

    array_index = atoi(s_array_index);
    if (0 == array_index)
    {
        if (0 != index)
        {
            printf("index value %d is invalid, should = 0\n", index);
            return -1;
        }
    }
    else
    {
        if (index >= array_index)
        {
            printf("index value %d is invalid, should < %d\n", index, array_index);
            return -1;
        }
    }

    if ((DBG_OP_WRITE == flag) && (1 != value_flag))
    {
        printf("Value field is necessary for write operation");
        return -1;
    }

    return 0;
}

static int rpc_op(int cmd, int flag, int index)
{
    RPC_CLIENT_DECL(3, INT32);
    RPC_CLIENT_ARG_INP(ARG_TYPE_INT32, cmd);
    RPC_CLIENT_ARG_INP(ARG_TYPE_INT32, flag);
    RPC_CLIENT_ARG_INP(ARG_TYPE_INT32, index);

    RPC_BT_SERVICE_CLIENT_DO_OP("x_mtkapi_bt_dbg_op");
    RPC_CLIENT_RETURN(ARG_TYPE_INT32, -1);
}

int main(int argc, char *argv[])
{
    int opt, ret = 0;
    int m_index = 0, s_index = 0, flag = 0, index = 0, value_flag = 0;

    while ((opt=getopt_long(argc, argv, "+h", main_options, NULL)) != -1) {
        switch (opt) {
        case 'h':
        default:
            print_help();
            exit(0);
        }
    }

    argc -= optind;
    argv += optind;
    optind = 0;

    if (argc < 1) {
        print_help();
        exit(0);
    }

    for (m_index = 0; m_cmd[m_index].c_mod; m_index++) {
        if (0 == strcmp(m_cmd[m_index].c_mod, argv[0]))
        {
            break;
        }
    }

    if (NULL == m_cmd[m_index].c_mod)
    {
        printf("The %s module is invalid.\n", argv[0]);
        exit(0);
    }

    for_each_opt(opt, sub_options, "+r:w:c:i:v:h") {
        switch (opt) {
        case 'r':
            flag = DBG_OP_READ;
            break;

        case 'w':
            flag = DBG_OP_WRITE;
            break;

        case 'c':
            s_index = atoi(optarg);
            break;

        case 'i':
            index = atoi(optarg);
            break;

        case 'v':
            value_flag = 1;
            break;

        case 'h':
        default:
            print_sub_help(m_index);
            exit(0);
        }
    }

    if (argc < 2) {
        print_sub_help(m_index);
        exit(0);
    }

    if (0 != param_check(m_index, s_index, index, flag, value_flag))
    {
        exit(0);
    }

    chmod("/tmp/mtk_bt_service",
          S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IWGRP|S_IXGRP|S_IROTH|S_IWOTH|S_IXOTH);
    printf("IPC/RPC initialize");

    rpc_init(NULL);
    c_rpc_init_mtk_bt_service_client();
    rpcu_tl_log_start();

    sleep(3);
    printf("initialize");

    ret = rpc_op(m_cmd[m_index].s_cmd[s_index].cmd, flag, index);
    if (ret)
    {
        printf(" rpc_op error %d\n", ret);
        return 0;
    }

    print_output(m_cmd[m_index].s_cmd[s_index].doc);
    return 0;
}

