
echo bluetooth use following toolchain
echo $CC
echo $CXX
echo ${MTK_BT_CHIP_ID}
CC=$CC
CXX=$CXX
if [ ! $Script_Dir ]; then
    Script_Dir=$(pwd)
fi
echo $Script_Dir
if [ ! $Bluetooth_Tool_Dir ]; then
    if [ `echo $(pwd) | grep -e "script/common"` ]; then
        export Bluetooth_Tool_Dir=${Script_Dir}/../..
    else
        export Bluetooth_Tool_Dir=${Script_Dir}/..
    fi
fi
echo $Bluetooth_Tool_Dir
if [ ! $Bluetooth_Stack_Dir ]; then
    export Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
fi
if [ ! $Bluetooth_Mw_Dir ]; then
    export Bluetooth_Mw_Dir=${Bluetooth_Tool_Dir}/../bluetooth_mw
fi
if [ ! $Bluetooth_Vendor_Lib_Dir ]; then
    export Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/vendor_libs
fi
if [ ! $Bluetooth_Prebuilts_Dir ]; then
    export Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
fi
if [ ! $Bluedroid_Libs_Path ]; then
    export Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib
fi

#platform related library:libz.so, libasound.so
if [ ! $External_Libs_Path ]; then
    export External_Libs_Path=${Bluetooth_Tool_Dir}/external_libs/platform
fi

#project related path, integrator should care these path
#BT_Tmp_Path is used for temporay path like as /tmp
if [ ! $BT_Tmp_Path ]; then
    export BT_Tmp_Path=/data/tmp
fi
#BT_Misc_Path is used for misc path like as /misc
if [ ! $BT_Misc_Path ]; then
    export BT_Misc_Path=/data/misc
fi
#BT_Misc_Path is used for etc path like as /etc
if [ ! $BT_Etc_Path ]; then
    export BT_Etc_Path=/data/etc
fi

#stack config file path:bt_stack.conf,bt_did.conf
if [ ! $Conf_Path ]; then
    export Conf_Path=${BT_Misc_Path}/bluedroid
fi
#stack record file path.
if [ ! $Cache_Path ]; then
    export Cache_Path=${BT_Misc_Path}
fi
#mw record file path, should the same with stack record path.
if [ ! $Storage_Path ]; then
    export Storage_Path=${BT_Misc_Path}
fi
#system library file path:libbluetooth.default.so...
if [ ! $Platform_Libs_Path ]; then
    export Platform_Libs_Path=/usr/lib64
fi
##########for different platform only need modify above export variable##########


echo "start build vendor lib"
sh build_vendorlibs.sh
if [ $? -ne 0 ]; then
    echo vendor_lib compile fail!!
    exit 1
fi

echo "start build stack"
sh build_stack.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbluetooth.default.so ]; then
    echo build libbluetooth.default.so failed, EXIT!
    exit 1
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libaudio.a2dp.default.so ]; then
    echo build libaudio.a2dp.default.so failed, EXIT!
    exit 1
fi

if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_stack.conf ]; then
    echo copy bt_stack.conf failed, EXIT!
    exit 1
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_did.conf ]; then
    echo copy bt_did.conf failed, EXIT!
    exit 1
fi

echo "start build btut"
sh build_btut.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btut ]; then
    echo build btut failed, EXIT!
    exit 1
fi

echo "start build mw"
sh build_mw.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-mw.so ]; then
    echo build libbt-mw.so failed, EXIT!
    exit 1
fi

#external_lib have ALSA library so should build playback module
if [ -f ${External_Libs_Path}/libasound.so ]; then
    echo "start build playback"
    sh build_playback.sh
    if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-alsa-playback.so ]; then
        echo build libbt-alsa-playback.so failed, EXIT!
        exit 1
    fi
else
    echo "no need build playback"
fi

#######################################--Begin RPC--########################################
echo "start build rpc"
sh build_rpc.sh
if [ $? -ne 0 ]; then
    echo rpc compile fail!!
    exit 1
fi
#######################################--End RPC--########################################

echo "start build demo"
sh build_rpc_dbg.sh
if [ $? -ne 0 ]; then
    echo rpc-dbg compile fail!!
    exit 1
fi

echo "start build demo"
sh build_mw_rpc_test.sh
if [ $? -ne 0 ]; then
    echo mw-rpc-test compile fail!!
    exit 1
fi

cd ${Script_Dir}
