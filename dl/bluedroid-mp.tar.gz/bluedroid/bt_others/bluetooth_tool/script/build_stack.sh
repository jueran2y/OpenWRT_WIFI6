
##############################################################################################
if [ ! $CC ]; then
  CC=/mtkoss/gnuarm/hard_4.9.2-r116_armv7a-cros/x86_64/armv7a/usr/x86_64-pc-linux-gnu/armv7a-cros-linux-gnueabi/gcc-bin/4.9.x-google/armv7a-cros-linux-gnueabi-gcc
  echo "single build?"
  echo "please asure the build environment correctly setting"
  echo $CC
fi
if [ ! $CXX ]; then
  CXX=/mtkoss/gnuarm/hard_4.9.2-r116_armv7a-cros/x86_64/armv7a/usr/x86_64-pc-linux-gnu/armv7a-cros-linux-gnueabi/gcc-bin/4.9.x-google/armv7a-cros-linux-gnueabi-g++
fi
if [ ! $Script_Dir ]; then
  Script_Dir=$(pwd)
  echo $Script_Dir
  if [[ $(pwd) =~ "script/common" ]]; then
    Bluetooth_Tool_Dir=${Script_Dir}/../..
  else
    Bluetooth_Tool_Dir=${Script_Dir}/..
  fi
fi
if [ ! $Bluetooth_Stack_Dir ]; then
  Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
fi
if [ ! $Bluetooth_Mw_Dir ]; then
  Bluetooth_Mw_Dir=${Bluetooth_Tool_Dir}/bluetooth_mw
fi
if [ ! $Bluetooth_Vendor_Lib_Dir ]; then
  Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/vendor_libs
fi
if [ ! $Bluetooth_Prebuilts_Dir ]; then
  Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
fi
if [ ! $Bluedroid_Libs_Path ]; then
  Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib
fi
#stack config file path:bt_stack.conf,bt_did.conf
if [ ! $Conf_Path ]; then
  Conf_Path=/data/misc/bluedroid
fi
#stack record file path.
if [ ! $Cache_Path ]; then
  Cache_Path=/data/misc
fi
#mw record file path, should the same with stack record path.
if [ ! $Storage_Path ]; then
  Storage_Path=/data/misc
fi
#system library file path:libbluetooth.default.so...
if [ ! $Platform_Libs_Path ]; then
  Platform_Libs_Path=/system/lib
fi
#for uhid.h depend on kernel version
if [ ! $Linux_Kernel_Version ]; then
    Linux_Kernel_Version=kernel-4.4
fi
##############################################################################################

Libhw_Include_Path=${Bluetooth_Tool_Dir}/libhardware/include
Core_Include_Path=${Bluetooth_Tool_Dir}/core/include
Audio_Include_Path=${Bluetooth_Tool_Dir}/media/audio/include
Zlib_Include_Path=${Bluetooth_Tool_Dir}/../../../zlib-1.2.8
Bluetooth_Mediatek_Include_Path=${Bluetooth_Stack_Dir}/mediatek/include
Zlib_Path=${Bluetooth_Tool_Dir}/../../../zlib-1.2.8

echo ${Zlib_Path}
echo ${Bluetooth_Tool_Dir}
cd ${Bluetooth_Tool_Dir}

#if [ ! -d "zlib-1.2.8" ]; then
#    tar -xvf zlib.tar.gz
#    cd zlib-1.2.8
#	export CC=${CC}
#    ./configure && make
#    cd ..
#fi

if [ ! -d "core" ]; then
    tar -xvf core.tar.gz
fi

if [ ! -d "libhardware" ]; then
    tar -xvf libhardware.tar.gz
fi

if [ ! -d "media" ]; then
    tar -xvf media.tar.gz
fi

cd ${Bluetooth_Mediatek_Include_Path}
echo $Linux_Kernel_Version
if [ $Linux_Kernel_Version = "kernel-3.10" ]; then
    cp -f uhid_3_10.h uhid.h
elif [ $Linux_Kernel_Version = "kernel-3.18" ]; then
    cp -f uhid_3_18.h uhid.h
elif [ $Linux_Kernel_Version = "kernel-4.4" ]; then
    cp -f uhid_4_4.h uhid.h
else
    cp -f uhid_3_18.h uhid.h
fi

cd ${Bluetooth_Stack_Dir}

if [ ! -d "third_party" ]; then
    tar -xvf third_party.tar.gz
fi

rm -rf out

if [[ $CC == *"musl"* ]]; then
    C_LIB=__C_LIB_MUSL__
else
    C_LIB=""
fi

echo "C_LIB = ${C_LIB}"

gn gen out/Default/ --args="c_lib=\"${C_LIB}\" libhw_include_path=\"${Libhw_Include_Path}\" core_include_path=\"${Core_Include_Path}\" audio_include_path=\"${Audio_Include_Path}\" zlib_include_path=\"${Zlib_Include_Path}\" zlib_path=\"-L${Zlib_Path}\" conf_path=\"${Conf_Path}\" cache_path=\"${Cache_Path}\" bt_tmp_path=\"${BT_Tmp_Path}\" bt_misc_path=\"${BT_Misc_Path}\" bt_etc_path=\"${BT_Etc_Path}\" cc=\"${CC}\" cxx=\"${CXX}\" bt_sys_log_flag=\"${BT_SYS_LOG_FLAG}\""

ninja -C out/Default all

cd ${Script_Dir}

if [ ! -d ${Bluetooth_Prebuilts_Dir}/lib ]; then
    mkdir -p ${Bluetooth_Prebuilts_Dir}/lib
fi

if [ ! -d ${Bluetooth_Prebuilts_Dir}/conf ]; then
    mkdir -p ${Bluetooth_Prebuilts_Dir}/conf
fi

#cp ${Bluetooth_Tool_Dir}/zlib-1.2.8/libz.so.1 ${Bluetooth_Prebuilts_Dir}/lib/
#ln -sf ${Bluetooth_Prebuilts_Dir}/lib/libz.so.1 ${Bluetooth_Prebuilts_Dir}/lib/libz.so
cp ${Bluetooth_Stack_Dir}/out/Default/libbluetooth.default.so ${Bluetooth_Prebuilts_Dir}/lib/
cp ${Bluetooth_Stack_Dir}/out/Default/libaudio.a2dp.default.so ${Bluetooth_Prebuilts_Dir}/lib/
cp ${Bluetooth_Stack_Dir}/conf/bt_stack.conf ${Bluetooth_Prebuilts_Dir}/conf/bt_stack.conf
cp ${Bluetooth_Stack_Dir}/conf/bt_did.conf ${Bluetooth_Prebuilts_Dir}/conf/bt_did.conf