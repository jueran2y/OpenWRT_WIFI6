
echo bluetooth use following toolchain
echo $CC
echo $CXX
CC=$CC
CXX=$CXX
export Script_Dir=$(pwd)
echo $Script_Dir
if [ `echo $(pwd) | grep -e "script/common"` ]; then
    export Bluetooth_Tool_Dir=${Script_Dir}/../..
else
    export Bluetooth_Tool_Dir=${Script_Dir}/..
fi

export Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
export Bluetooth_Mw_Dir=${Bluetooth_Tool_Dir}/../bluetooth_mw
export Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/vendor_libs
export Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
export Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib
#platform related library:libz.so, libasound.so
export External_Libs_Path=${Bluetooth_Tool_Dir}/external_libs/platform

#project related path, integrator should care these path
#BT_Tmp_Path is used for temporay path like as /tmp
export BT_Tmp_Path=/data/tmp
#BT_Misc_Path is used for misc path like as /misc
export BT_Misc_Path=/data/misc
#BT_Misc_Path is used for etc path like as /etc
export BT_Etc_Path=/data/etc

#stack config file path:bt_stack.conf,bt_did.conf
export Conf_Path=${BT_Misc_Path}/bluedroid
#stack record file path.
export Cache_Path=${BT_Misc_Path}
#mw record file path, should the same with stack record path.
export Storage_Path=${BT_Misc_Path}
#system library file path:libbluetooth.default.so...
export Platform_Libs_Path=/usr/lib64
##########for different platform only need modify above export variable##########


echo "start build vendor lib"
sh build_vendorlibs.sh
if [ $? -ne 0 ]; then
    echo vendor_lib compile fail!!
    exit 1
fi

echo "start build stack"
sh build_stack.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbluetooth.default.so ]; then
    echo build libbluetooth.default.so failed, EXIT!
    exit 1
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libaudio.a2dp.default.so ]; then
    echo build libaudio.a2dp.default.so failed, EXIT!
    exit 1
fi

if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_stack.conf ]; then
    echo copy bt_stack.conf failed, EXIT!
    exit 1
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_did.conf ]; then
    echo copy bt_did.conf failed, EXIT!
    exit 1
fi

echo "start build btut"
sh build_btut.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btut ]; then
    echo build btut failed, EXIT!
    exit 1
fi

echo "start build mw"
sh build_mw.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-mw.so ]; then
    echo build libbt-mw.so failed, EXIT!
    exit 1
fi

#external_lib have ALSA library so should build playback module
if [ -f ${External_Libs_Path}/libasound.so ]; then
    echo "start build playback"
    sh build_playback.sh
    if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-alsa-playback.so ]; then
        echo build libbt-alsa-playback.so failed, EXIT!
        exit 1
    fi
else
    echo "no need build playback"
fi

echo "start build demo"
sh build_mwtest.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btmw-test ]; then
    echo build btmw-test failed, EXIT!
    exit 1
fi

cd ${Script_Dir}
