
if [ ! $Script_Dir ]; then
    Script_Dir=$(pwd)
    echo $Script_Dir
    if [[ $(pwd) =~ "script/common" ]]; then
        Bluetooth_Tool_Dir=${Script_Dir}/../..
    else
        Bluetooth_Tool_Dir=${Script_Dir}/..
    fi
fi
if [ ! $Bluetooth_Vendor_Lib_Dir ]; then
    Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/vendor_libs
fi

rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbt-vendor.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbluetooth_hw_test.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbluetooth_mtk_pure.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbluetooth_relayer.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbluetoothem_mtk.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/bin/autobt

cd ${Bluetooth_Tool_Dir}
rm -rf libhardware

cd ${Bluetooth_Vendor_Lib_Dir}
rm -rf out

cd ${Script_Dir}

