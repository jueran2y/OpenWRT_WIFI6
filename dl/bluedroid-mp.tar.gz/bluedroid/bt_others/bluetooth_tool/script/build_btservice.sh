
Mw_Config_Path=${Bluetooth_Mw_Dir}/inc/config
Mw_Include_Path=${Bluetooth_Mw_Dir}/inc
Mw_Inc_Path=${Bluetooth_Mw_Dir}/sdk/inc
Mw_Src_Inc_Path=${Bluetooth_Mw_Dir}/sdk/src/inc
Mw_ALSA_Inc_Path=${Bluetooth_Mw_Dir}/playback/ALSA
MTK_Bt_Service_Server_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_server/inc
MTK_Bt_Service_Client_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_client/inc
MTK_RPC_IPC_Inc_Path=${Bluetooth_Mw_Dir}/rpc_ipc/inc

Libbt_Mw_Path=${Bluetooth_Prebuilts_Dir}/lib
Libbt_Alsa_Playback_Path=${External_Libs_Path}/
Libipcrpc_Path=${Bluetooth_Prebuilts_Dir}/lib
Libmtk_Bt_Service_Server_Path=${Bluetooth_Prebuilts_Dir}/lib
Libmtk_Bt_Service_Client_Path=${Bluetooth_Prebuilts_Dir}/lib

#yocto
if [ "$MTK_BT_C4A" = "no" ]; then
  #yocto use coredump backtrace when crash
  BT_COREDUMP_BACKTRACE=-DMTK_BT_COREDUMP_BACKTRACE
fi

cd ${Bluetooth_Mw_Dir}/btservice

rm -rf out

gn gen out/Default/ --args="mw_config_path=\"${Mw_Config_Path}\" mw_include_path=\"${Mw_Include_Path}\" mw_inc_path=\"${Mw_Inc_Path}\" mw_src_inc_path=\"${Mw_Src_Inc_Path}\" mw_alsa_inc_path=\"${Mw_ALSA_Inc_Path}\" mtk_bt_service_server_inc_path=\"${MTK_Bt_Service_Server_Inc_Path}\" mtk_bt_service_client_inc_path=\"${MTK_Bt_Service_Client_Inc_Path}\" mtk_rpcipc_inc_path=\"${MTK_RPC_IPC_Inc_Path}\" libbt_mw_path=\"-L${Libbt_Mw_Path}\" libipcrpc_path=\"-L${Libipcrpc_Path}\" libmtk_bt_service_server_path=\"-L${Libmtk_Bt_Service_Server_Path}\" libmtk_bt_service_client_path=\"-L${Libmtk_Bt_Service_Client_Path}\" libbt_alsa_playback_path=\"-L${Libbt_Alsa_Playback_Path}\" bt_sys_log_flag=\"${BT_SYS_LOG_FLAG}\" bt_tmp_path=\"${BT_Tmp_Path}\" bt_misc_path=\"${BT_Misc_Path}\" bt_etc_path=\"${BT_Etc_Path}\" cc=\"${CC}\" cxx=\"${CXX}\" bt_backtrace=\"${BT_COREDUMP_BACKTRACE}\""
ninja -C out/Default all

cd ${Script_Dir}

if [ ! -d ${Bluetooth_Prebuilts_Dir}/bin ]; then
    mkdir -p ${Bluetooth_Prebuilts_Dir}/bin
fi
if [ -f ${Bluetooth_Mw_Dir}/btservice/out/Default/btservice ]; then
    cp ${Bluetooth_Mw_Dir}/btservice/out/Default/btservice ${Bluetooth_Prebuilts_Dir}/bin/
else
    exit 1
fi
