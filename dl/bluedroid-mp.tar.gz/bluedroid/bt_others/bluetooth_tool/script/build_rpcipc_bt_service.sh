
MTK_Bt_Service_Server_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_server/inc
MTK_Bt_Service_Client_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_client/inc
MTK_Bt_Service_Client_Src_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_client/src/inc
MTK_Bt_Service_Server_Src_Inc_Path=${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/mtk_bt_service_server/src/inc
MTK_RPC_IPC_Inc_Path=${Bluetooth_Mw_Dir}/rpc_ipc/inc
Mw_Include_Path=${Bluetooth_Mw_Dir}/inc
Mw_Config_Path=${Bluetooth_Mw_Dir}/inc/config

Libipcrpc_Path=${Bluetooth_Prebuilts_Dir}/lib

cd ${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service

rm -rf out

gn gen out/Default/ --args="mtk_bt_service_server_inc_path=\"${MTK_Bt_Service_Server_Inc_Path}\" mtk_bt_service_client_inc_path=\"${MTK_Bt_Service_Client_Inc_Path}\" mtk_bt_service_server_src_inc_path=\"${MTK_Bt_Service_Server_Src_Inc_Path}\" mtk_bt_service_client_src_inc_path=\"${MTK_Bt_Service_Client_Src_Inc_Path}\" mtk_rpcipc_inc_path=\"${MTK_RPC_IPC_Inc_Path}\" mw_include_path=\"${Mw_Include_Path}\" mw_config_path=\"${Mw_Config_Path}\" libipcrpc_path=\"-L${Libipcrpc_Path}\" bt_sys_log_flag=\"${BT_SYS_LOG_FLAG}\" bt_tmp_path=\"${BT_Tmp_Path}\" bt_misc_path=\"${BT_Misc_Path}\" bt_etc_path=\"${BT_Etc_Path}\" cc=\"${CC}\" cxx=\"${CXX}\""
ninja -C out/Default all

cd ${Script_Dir}

if [ ! -d ${Bluetooth_Prebuilts_Dir}/lib ]; then
    mkdir -p ${Bluetooth_Prebuilts_Dir}/lib
fi


if [ -f ${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/out/Default/libmtk_bt_service_server.so ]; then
    cp ${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/out/Default/libmtk_bt_service_server.so ${Bluetooth_Prebuilts_Dir}/lib/
else
    exit 1
fi
if [ -f ${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/out/Default/libmtk_bt_service_client.so ]; then
    cp ${Bluetooth_Mw_Dir}/btmw_rpc_test/mtk_rpcipc_bt_service/out/Default/libmtk_bt_service_client.so ${Bluetooth_Prebuilts_Dir}/lib/
else
    exit 1
fi
