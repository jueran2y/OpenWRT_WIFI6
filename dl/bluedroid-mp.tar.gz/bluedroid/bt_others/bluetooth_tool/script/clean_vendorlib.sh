if [ ! $Script_Dir ]; then
  Script_Dir=$(pwd)
  echo $Script_Dir
  if [[ $(pwd) =~ "script/common" ]]; then
    Bluetooth_Tool_Dir=${Script_Dir}/../..
  else
    Bluetooth_Tool_Dir=${Script_Dir}/..
  fi
fi

rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbt-vendor.so
rm -rf ${Bluetooth_Tool_Dir}/../vendor_lib/prebuilts/lib/libbt-vendor.so
rm -rf ${Bluetooth_Tool_Dir}/../vendor_lib/external/libhardware
rm -rf ${Bluetooth_Tool_Dir}/../vendor_lib/prebuilts
rm -rf ${Bluetooth_Tool_Dir}/../vendor_lib/out

