#! /bin/bash

##############################################################################################
if [ ! $CC ]; then
  CC=/mtkoss/gnuarm/hard_4.9.2-r116_armv7a-cros/x86_64/armv7a/usr/x86_64-pc-linux-gnu/armv7a-cros-linux-gnueabi/gcc-bin/4.9.x-google/armv7a-cros-linux-gnueabi-gcc
  echo "single build?"
  echo "please asure the build environment correctly setting"
  echo $CC
fi
if [ ! $CXX ]; then
  CXX=/mtkoss/gnuarm/hard_4.9.2-r116_armv7a-cros/x86_64/armv7a/usr/x86_64-pc-linux-gnu/armv7a-cros-linux-gnueabi/gcc-bin/4.9.x-google/armv7a-cros-linux-gnueabi-g++
fi
if [ ! $Script_Dir ]; then
  Script_Dir=$(pwd)
  echo $Script_Dir
  if [[ $(pwd) =~ "script/common" ]]; then
    Bluetooth_Tool_Dir=${Script_Dir}/../..
  else
    Bluetooth_Tool_Dir=${Script_Dir}/..
  fi
fi
if [ ! $Bluetooth_Stack_Dir ]; then
  Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
fi
if [ ! $Bluetooth_Mw_Dir ]; then
  Bluetooth_Mw_Dir=${Bluetooth_Tool_Dir}/bluetooth_mw
fi
if [ ! $Bluetooth_Vendor_Lib_Dir ]; then
  Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/vendor_libs
fi
if [ ! $Bluetooth_Prebuilts_Dir ]; then
  Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
fi
if [ ! $Bluedroid_Libs_Path ]; then
  Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib
fi
#stack config file path:bt_stack.conf,bt_did.conf
if [ ! $Conf_Path ]; then
  Conf_Path=/data/misc/bluedroid
fi
#stack record file path.
if [ ! $Cache_Path ]; then
  Cache_Path=/data/misc
fi
#mw record file path, should the same with stack record path.
if [ ! $Storage_Path ]; then
  Storage_Path=/data/misc
fi
#system library file path:libbluetooth.default.so...
if [ ! $Platform_Libs_Path ]; then
  Platform_Libs_Path=/system/lib
fi
#system library file path:libbluetooth.default.so...
if [ ! $Bluetooth_Boots_Dir ]; then
  Bluetooth_Boots_Dir=${Bluetooth_Tool_Dir}/boots
fi
##############################################################################################

Boots_Socket_Path=$Cache_Path

cd ${Bluetooth_Boots_Dir}

rm -rf out

gn gen out/Default/ --args="boots_socket_path = \"${Boots_Socket_Path}\" cc=\"${CC}\" cxx=\"${CXX}\""
ninja -C out/Default all

cd ${Script_Dir}

if [ ! -d ${Bluetooth_Prebuilts_Dir}/bin ]; then
    mkdir -p ${Bluetooth_Prebuilts_Dir}/bin
fi

if [ -f ${Bluetooth_Boots_Dir}/out/Default/boots_srv ]; then
    cp ${Bluetooth_Boots_Dir}/out/Default/boots_srv ${Bluetooth_Prebuilts_Dir}/bin/
else
    exit 1
fi

if [ -f ${Bluetooth_Boots_Dir}/out/Default/boots ]; then
    cp ${Bluetooth_Boots_Dir}/out/Default/boots ${Bluetooth_Prebuilts_Dir}/bin/
else
    exit 1
fi
