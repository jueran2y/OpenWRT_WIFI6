
if [ ! $Script_Dir ]; then
  Script_Dir=$(pwd)
  echo $Script_Dir
  if [[ $(pwd) =~ "script/common" ]]; then
    Bluetooth_Tool_Dir=${Script_Dir}/../..
  else
    Bluetooth_Tool_Dir=${Script_Dir}/..
  fi
fi

if [ ! $Bluetooth_Stack_Dir ]; then
  Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
fi

rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libbluetooth.default.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libaudio.a2dp.default.so
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/lib/libz.so*
rm -rf ${Bluetooth_Tool_Dir}/prebuilts/conf/*.conf
rm -rf ${Bluetooth_Tool_Dir}/prebuilts
rm -rf ${Script_Dir}/prebuilts
rm -rf ${Script_Dir}/../prebuilts

cd ${Bluetooth_Tool_Dir}
rm -rf zlib-1.2.8
rm -rf core
rm -rf libhardware
rm -rf media
rm -rf libevent-*

cd ${Bluetooth_Stack_Dir}

rm -rf out
rm -rf third_party

cd ${Script_Dir}
