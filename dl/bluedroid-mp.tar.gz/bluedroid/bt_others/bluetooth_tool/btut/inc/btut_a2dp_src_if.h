#ifndef __BTUT_A2DP_SRC_IF_H__
#define __BTUT_A2DP_SRC_IF_H__

#define CMD_KEY_A2DP_SRC        "A2DP_SRC"

int btut_a2dp_src_init();
int btut_a2dp_src_deinit();

#endif /* __BTUT_A2DP_SRC_IF_H__ */
