/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2014. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <cutils/properties.h>

#include "bt_mtk.h"
#include "CFG_BT_File.h"
#include "CFG_BT_Default.h"
#include <sys/stat.h>
#include <sys/socket.h>
#define BTPROTO_HCI     1
#define HCI_CHANNEL_USER        1

/**************************************************************************
 *                  G L O B A L   V A R I A B L E S                       *
***************************************************************************/

const bt_vendor_callbacks_t *bt_vnd_cbacks = NULL;
static int  bt_fd = -1;

#if BT_FLASH_SUPPORT
#include <sys/ioctl.h>

#define COMBO_BT_OFFSET 	0
#define COMBO_BT_BDADDR_LEN	0x6
#define COMBO_BT_VOICE_LEN	0x2
#define COMBO_BT_CODEC_LEN	0x4
#define COMBO_BT_RADIO_LEN	0x2
#define COMBO_BT_SLEEP_LEN	0x7
#define COMBO_BT_OTHER_LEN	0x2
#define COMBO_BT_TX_PWR_LEN	0x6
#define COMBO_BT_COEX_LEN	0x6

#define COMBO_BT_BDADDR_OFFSET	(0x1a + COMBO_BT_OFFSET)
#define COMBO_BT_RADIO_OFFSET	(0x15e + COMBO_BT_OFFSET)
#define COMBO_BT_TX_PWR_OFFSET	(0x148 + COMBO_BT_OFFSET)

struct mtd_info_user {
	u_char type;
	u_int32_t flags;
	u_int32_t size;
	u_int32_t erasesize;
	u_int32_t oobblock;
	u_int32_t oobsize;
	u_int32_t ecctype;
	u_int32_t eccsize;
};

struct erase_info_user {
	u_int32_t start;
	u_int32_t length;
};

#define MEMGETINFO	_IOR('M', 1, struct mtd_info_user)
#define MEMERASE	_IOW('M', 2, struct erase_info_user)
#define min(a, b) ((a) < (b) ? (a) : (b))

#endif

/**************************************************************************
 *              F U N C T I O N   D E C L A R A T I O N S                 *
***************************************************************************/

extern BOOL BT_InitDevice(
    UINT32  chipId,
    PUCHAR  pucNvRamData,
    UINT32  u4Baud,
    UINT32  u4HostBaud,
    UINT32  u4FlowControl,
    SETUP_UART_PARAM_T setup_uart_param
);

extern BOOL BT_InitSCO(VOID);
extern BOOL BT_DeinitDevice(VOID);
extern VOID BT_Cleanup(VOID);

/**************************************************************************
 *                          F U N C T I O N S                             *
***************************************************************************/

struct sockaddr_hci {
  sa_family_t    hci_family;
  unsigned short hci_dev;
  unsigned short hci_channel;
};
static BOOL is_memzero(unsigned char *buf, int size)
{
    int i;
    for (i = 0; i < size; i++) {
        if (*(buf+i) != 0) return FALSE;
    }
    return TRUE;
}

/* Register callback functions to libbt-hci.so */
void set_callbacks(const bt_vendor_callbacks_t *p_cb)
{
    bt_vnd_cbacks = p_cb;
}

/* Cleanup callback functions previously registered */
void clean_callbacks(void)
{
    bt_vnd_cbacks = NULL;
}
#define CUST_BT_SERIAL_PORT "/dev/stpbt"
/* Initialize UART port */
int init_uart(void)
{
    int index = 0, ret = 0;
    struct sockaddr_hci addr;
    struct stat s;

    LOG_TRC();
    if (stat(CUST_BT_SERIAL_PORT, &s) == 0) {
        for (index = 0; index < 10; index++)
        {
            bt_fd = open(CUST_BT_SERIAL_PORT, O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
            if (bt_fd < 0) {
                LOG_ERR("Can't open %s (%s), errno[%d]\n", CUST_BT_SERIAL_PORT, strerror(errno), errno);
                usleep(100000); //sleep 100ms
                bt_fd = -1;
            }
            else {
                break;
            }
        }
    } else {
        bt_fd = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
        if (bt_fd < 0) {
            LOG_ERR("socket create error\n");
            bt_fd = -1;
        } else {
            memset(&addr, 0, sizeof(addr));
            addr.hci_family = AF_BLUETOOTH;
            addr.hci_dev = 0;
            addr.hci_channel = HCI_CHANNEL_USER;
            if(ret = bind(bt_fd, (struct sockaddr *) &addr, sizeof(addr))) {
               LOG_ERR("bind error %s\n", strerror(errno));
               LOG_ERR("bind error ret = %d\n", ret);
            }
            LOG_ERR("init done\n");
        }
    }


    if (bt_fd < 0) {
        LOG_ERR("Can't open serial port stpbt\n");
        return -1;
    }
    return bt_fd;
}

/* Close UART port previously opened */
void close_uart(void)
{
    if (bt_fd >= 0) close(bt_fd);
    bt_fd = -1;
}

void vendor_op_lmp_set_mode(void)
{

    if (bt_vnd_cbacks) {
        bt_vnd_cbacks->lpm_cb(BT_VND_OP_RESULT_SUCCESS);
    }
}

static int bt_get_combo_id(unsigned int *pChipId)
{
#ifdef MTK_MT7622
    *pChipId = 0x7622;
#endif
#ifdef MTK_MT7628
    *pChipId = 0x7628;
#endif

    LOG_DBG("Combo chip id %x\n", *pChipId);
    return 0;
}

/* MTK specific chip initialize process */
int mtk_fw_cfg(void)
{
    unsigned int chipId = 0;
    unsigned char ucNvRamData[sizeof(ap_nvram_btradio_struct)] = {0};
    unsigned int speed = 0;
    unsigned int flow_control = 0;
    SETUP_UART_PARAM_T uart_setup_callback = NULL;

    LOG_TRC();

    if (bt_vnd_cbacks) {
        LOG_ERR("bt_vnd_cbacks fwcfg_cb done\n");
        bt_vnd_cbacks->fwcfg_cb(BT_VND_OP_RESULT_SUCCESS);
    }
    return 0;
}

/* MTK specific SCO/PCM configuration */
int mtk_sco_cfg(void)
{
    return (BT_InitSCO() == TRUE ? 0 : -1);
}

/* MTK specific deinitialize process */
int mtk_prepare_off(void)
{
    /*
    * On KK, BlueDroid adds BT_VND_OP_EPILOG procedure when BT disable:
    *   - 1. BT_VND_OP_EPILOG;
    *   - 2. In vendor epilog_cb, send EXIT event to bt_hc_worker_thread;
    *   - 3. Wait for bt_hc_worker_thread exit;
    *   - 4. userial close;
    *   - 5. vendor cleanup;
    *   - 6. Set power off.
    * On L, the disable flow is modified as below:
    *   - 1. userial Rx thread exit;
    *   - 2. BT_VND_OP_EPILOG;
    *   - 3. Write reactor->event_fd to trigger bt_hc_worker_thread exit
    *        (not wait to vendor epilog_cb and do nothing in epilog_cb);
    *   - 4. Wait for bt_hc_worker_thread exit;
    *   - 5. userial close;
    *   - 6. Set power off;
    *   - 7. vendor cleanup.
    *
    * It seems BlueDroid does not expect Tx/Rx interaction with chip during
    * BT_VND_OP_EPILOG procedure, and also does not need to do it in a new
    * thread context (NE may occur in __pthread_start if bt_hc_worker_thread
    * has already exited).
    * So BT_VND_OP_EPILOG procedure may be not for chip deinitialization,
    * do nothing, just notify success.
    *
    * [FIXME!!]How to do if chip deinit is needed?
    */
    //return (BT_DeinitDevice() == TRUE ? 0 : -1);
    if (bt_vnd_cbacks) {
        bt_vnd_cbacks->epilog_cb(BT_VND_OP_RESULT_SUCCESS);
    }
    return 0;
}

/* Cleanup driver resources, e.g thread exit */
void clean_resource(void)
{
    BT_Cleanup();
}
#if BT_FLASH_SUPPORT
int mtd_open(const char *name, int flags)
{
	FILE *fp;
	char dev[80];
	int i, ret;

	if ((fp = fopen("/proc/mtd", "r"))) {
		while (fgets(dev, sizeof(dev), fp)) {
			if (sscanf(dev, "mtd%d:", &i) && strstr(dev, name)) {
				snprintf(dev, sizeof(dev), "/dev/mtd/%d", i);
				if ((ret = open(dev, flags)) < 0) {
					snprintf(dev, sizeof(dev), "/dev/mtd%d", i);
					ret = open(dev, flags);
				}
				fclose(fp);
				return ret;
			}
		}
		fclose(fp);
	}
	return -1;
}

static int flash_read_offset(const unsigned int from, const unsigned int len, char *buf)
{
	int fd, ret;
	struct mtd_info_user info;

	fd = mtd_open("Factory", O_RDONLY);
	if (fd < 0) {
		fprintf(stderr, "Could not open mtd device\n");
		return -1;
	}

	if (ioctl(fd, MEMGETINFO, &info)) {
		fprintf(stderr, "Could not get mtd device info\n");
		close(fd);
		return -1;
	}
	if (len > info.size) {
		fprintf(stderr, "Too many bytes - %zd > %d bytes\n", len, info.erasesize);
		close(fd);
		return -1;
	}

	lseek(fd, from, SEEK_SET);
	ret = read(fd, buf, len);
	if (ret == -1) {
		fprintf(stderr, "Reading from mtd failed\n");
		close(fd);
		return -1;
	}

	close(fd);
	return ret;
}

static int flash_write_offset(const unsigned int offset, char *buffer, const unsigned int length)
{
     int fd, ret = 0;
     char *bak = NULL;
     struct mtd_info_user info;
     struct erase_info_user ei;
     size_t rest = 0;
     unsigned int to = offset;
     unsigned int len = length;
     char *buf = buffer;

     fd = mtd_open("Factory", O_RDWR | O_SYNC);
     if (fd < 0) {
         fprintf(stderr, "Could not open mtd device\n");
         return -1;
     }

     if (ioctl(fd, MEMGETINFO, &info)) {
         fprintf(stderr, "Could not get mtd device info\n");
         close(fd);
         return -1;
     }
     if (len > info.size) {
         fprintf(stderr, "Too many bytes: %zd > %d bytes\n", len, info.erasesize);
         close(fd);
         return -1;
     }

     while (len > 0) {
         if ((to & (info.erasesize-1)) || (len < info.erasesize)) {
             int piece_size;
             unsigned int piece, bakaddr;

             bak = (char *)malloc(info.erasesize);
             if (bak == NULL) {
                 fprintf(stderr, "Not enough memory\n");
                 close(fd);
                 return -1;
             }

             bakaddr = to & ~(info.erasesize - 1);
             lseek(fd, bakaddr, SEEK_SET);

             ret = read(fd, bak, info.erasesize);
             if (ret == -1) {
                 fprintf(stderr, "Reading from mtd failed\n");
                 close(fd);
                 free(bak);
                 return -1;
             }

             piece = to & (info.erasesize - 1);
             rest = info.erasesize - piece;
             piece_size = min(len, rest);
             memcpy(bak + piece, buf, piece_size);

             ei.start = bakaddr;
             ei.length = info.erasesize;
             if (ioctl(fd, MEMERASE, &ei) < 0) {
                 fprintf(stderr, "Erasing mtd failed\n");
                 close(fd);
                 free(bak);
                 return -1;
             }

             lseek(fd, bakaddr, SEEK_SET);
             ret = write(fd, bak, info.erasesize);
             if (ret == -1) {
                 fprintf(stderr, "Writing to mtd failed\n");
                 close(fd);
                 free(bak);
                 return -1;
             }

             free(bak);
             buf += piece_size;
             to += piece_size;
             len -= piece_size;
         }
         else {
             ei.start = to;
             ei.length = info.erasesize;
             if (ioctl(fd, MEMERASE, &ei) < 0) {
                 fprintf(stderr, "Erasing mtd failed\n");
                 close(fd);
                 return -1;
             }

             ret = write(fd, buf, info.erasesize);
             if (ret == -1) {
                 fprintf(stderr, "Writing to mtd failed\n");
                 close(fd);
                 free(bak);
                 return -1;
             }

             buf += info.erasesize;
             to += info.erasesize;
             len -= info.erasesize;
         }
     }

     close(fd);
     return ret;
}

static int bt_read_flash(unsigned char *pucNvRamData)
{
    int ret;
    ap_nvram_btradio_struct bt_nvram;
    memset(&bt_nvram, '0', sizeof(ap_nvram_btradio_struct));
    ret = flash_read_offset(COMBO_BT_BDADDR_OFFSET, COMBO_BT_BDADDR_LEN, bt_nvram.addr);
    ret = flash_read_offset(COMBO_BT_RADIO_OFFSET, COMBO_BT_RADIO_LEN, bt_nvram.Radio);
    ret = flash_read_offset(COMBO_BT_TX_PWR_OFFSET, COMBO_BT_TX_PWR_LEN, bt_nvram.TxPWOffset);
    LOG_DBG("[BDAddr %02x-%02x-%02x-%02x-%02x-%02x]\n",
        bt_nvram.addr[0], bt_nvram.addr[1],
        bt_nvram.addr[2], bt_nvram.addr[3],
        bt_nvram.addr[4], bt_nvram.addr[5]);
    LOG_DBG("[Radio %02x-%02x]\n",
        bt_nvram.Radio[0], bt_nvram.Radio[1]);
    LOG_DBG("[TxPWOffset %02x-%02x-%02x-%02x-%02x-%02x]\n",
        bt_nvram.TxPWOffset[0], bt_nvram.TxPWOffset[1],
        bt_nvram.TxPWOffset[2], bt_nvram.TxPWOffset[3],
        bt_nvram.TxPWOffset[4], bt_nvram.TxPWOffset[5]);
    memcpy(pucNvRamData, &bt_nvram, sizeof(ap_nvram_btradio_struct));
    return ret;
}

int bt_write_flash(unsigned char *pucNvRamData)
{
    int ret;
    ap_nvram_btradio_struct bt_nvram;
    memset(&bt_nvram, '0', sizeof(ap_nvram_btradio_struct));
    ret = flash_write_offset(COMBO_BT_BDADDR_OFFSET, pucNvRamData, COMBO_BT_BDADDR_LEN);
    ret = flash_read_offset(COMBO_BT_BDADDR_OFFSET, COMBO_BT_BDADDR_LEN, bt_nvram.addr);
    LOG_DBG("[BDAddr %02x-%02x-%02x-%02x-%02x-%02x]\n",
        bt_nvram.addr[0], bt_nvram.addr[1],
        bt_nvram.addr[2], bt_nvram.addr[3],
        bt_nvram.addr[4], bt_nvram.addr[5]);

    return ret;
}

#endif
