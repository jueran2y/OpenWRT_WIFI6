/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/******************************************************************************
*						 C O M P I L E R   F L A G S
*******************************************************************************
*/

/******************************************************************************
*					E X T E R N A L   R E F E R E N C E S
*******************************************************************************
*/
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <syslog.h>
#include <termios.h>
#include <time.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/uio.h>
#include <linux/serial.h> /* struct serial_struct  */

/******************************************************************************
*							  C O N S T A N T S
*******************************************************************************
*/
#ifndef N_MTKSTP
#define N_MTKSTP	(15 + 1)  /* MediaTek WCN Serial Transport Protocol */
#endif

#define HCIUARTSETPROTO _IOW('U', 200, int)
#define HCIUARTSETBAUD _IOW('U', 201, int)
#define HCIUARTGETBAUD _IOW('U', 202, int)
#define HCIUARTSETSTP _IOW('U', 203, int)
#define HCIUARTLOADPATCH _IOW('U', 204, int)
#define HCIUARTSETWAKEUP _IOW('U', 205, int)
#define HCIUARTLOADFLASH _IOW('U', 206, int)
#define HCIUARTSTPENABLE _IOW('U', 207, int)
#define HCIUARTCCCI _IOW('U', 208, int)

#define CUST_COMBO_WMT_DEV "/dev/stpwmt"
#define CUST_COMBO_STP_DEV "/dev/ttyUSB0"
#define CUST_COMBO_PATCH_PATH "/etc/firmware" /* -- for ALPS */


#define CUST_BAUDRATE_DFT (115200)

#define CUST_MULTI_PATCH (1)

#ifdef CFG_MTK_SOC_CONSYS_SUPPORT
#define CUST_MTK_SOC_CONSYS (1)
#else
#define CUST_MTK_SOC_CONSYS (0)
#endif

#define MAX_CMD_LEN (NAME_MAX+1)

enum UART_FC {
	UART_DISABLE_FC = 0, /*NO flow control*/
	/*MTK SW Flow Control, differs from Linux Flow Control*/
	UART_MTK_SW_FC = 1,
	UART_LINUX_FC = 2,   /*Linux SW Flow Control*/
	UART_HW_FC = 3,	  /*HW Flow Control*/
};

#if 0
#ifdef ANDROID
struct SYS_PROPERTY {
	const char *key;
	const char *defValue;
	char value[PROPERTY_VALUE_MAX];

};
#endif
#endif

struct UART_CONFIG {
	enum UART_FC fc;
	int parity;
	int stop_bit;
	int iBaudrate;
};

#if 0
#if CUST_MULTI_PATCH
struct STP_PATCH_INFO {
	int dowloadSeq;
	char addRess[4];
	char patchName[256];
};
#endif
struct CHIP_ANT_MODE_INFO {
	const char *pCfgItem;
	char cfgItemValue[NAME_MAX + 1];
};


struct CHIP_MODE_INFO {
	int chipId;
	enum STP_MODE stpMode;
	CHIP_ANT_MODE_INFO antMode;
};
#ifdef ANDROID
#ifndef WMT_PLAT_APEX
CHIP_MODE_INFO gChipModeInfo[] = {
	{0x6620, STP_UART_FULL, {"mt6620.defAnt", "mt6620_ant_m3.cfg"} },
	{0x6628, STP_UART_FULL, {"mt6628.defAnt", "mt6628_ant_m1.cfg"} },
	{0x6630, STP_UART_FULL, {"mt6630.defAnt", "mt6630_ant_m1.cfg"} },
};
#else
CHIP_MODE_INFO gChipModeInfo[] = {
	{0x6620, STP_UART_FULL, {"mt6620.defAnt", "WMT.cfg"} },
	{0x6628, STP_UART_FULL, {"mt6628.defAnt", "WMT.cfg"} },
	{0x6630, STP_UART_FULL, {"mt6630.defAnt", "WMT.cfg"} },
};
#endif
#else
CHIP_MODE_INFO gChipModeInfo[] = {
	{0x6620, STP_UART_FULL, {"mt6620.defAnt", "WMT.cfg"} },
	{0x6628, STP_UART_FULL, {"mt6628.defAnt", "WMT.cfg"} },
	{0x6630, STP_UART_FULL, {"mt6630.defAnt", "WMT.cfg"} },
};
#endif
#endif
/******************************************************************************
*							 D A T A   T Y P E S
*******************************************************************************
*/
#if 0
struct cmd_hdr {
	char *pCmd;
	int (*hdr_func)(struct STP_PARAMS_CONFIG *pStpParamsConfig);
};
#endif
struct speed_map {
	unsigned int baud;
	speed_t	  speed;
};

/******************************************************************************
*								 M A C R O S
*******************************************************************************
*/
#define INIT_CMD(c, e, s) \
	{.cmd = c, \
	.cmd_sz = sizeof(c), \
	.evt = e, \
	.evt_sz = sizeof(e), \
	.str = s}

/******************************************************************************
*				   F U N C T I O N   D E C L A R A T I O N S
*******************************************************************************
*/
static int set_speed(int fd, struct termios *ti, int speed);
static speed_t get_speed(int baudrate);


/******************************************************************************
*							P U B L I C   D A T A
*******************************************************************************
*/

/******************************************************************************
*						   P R I V A T E   D A T A
*******************************************************************************
*/
static struct speed_map speeds[] = {
	{115200,	B115200},
	{921600,	B921600},
	{1000000,	B1000000},
	{1152000,	B1152000},
	{2000000,	B2000000},
	{2500000,	B2500000},
	{3000000,	B3000000},
	{3500000,	B3500000},
	{4000000,	B4000000},
};

static int gTtyFd = -1;
#if 0
static struct STP_UART_CONFIG g_stp_uart_config;
static volatile sig_atomic_t __io_canceled;
static char gPatchName[NAME_MAX+1] = {0};
static char gPatchFolder[NAME_MAX+1] = {0};
static char gStpDev[NAME_MAX+1] = {0};
static int gStpMode = -1;
static char gWmtCfgName[NAME_MAX+1] = {0};
static int gWmtFd = -1;
static int gWmtBtFd = -1;
static char gCmdStr[MAX_CMD_LEN] = {0};
static char gRespStr[MAX_CMD_LEN] = {0};
static int gFmMode = 2; /* 1: i2c, 2: comm I/F */
static const char *gUartName;
#if CUST_MULTI_PATCH
static unsigned int gPatchNum;
static unsigned int gDwonSeq;
static P_STP_PATCH_INFO pStpPatchInfo;
static STP_PATCH_INFO gStpPatchInfo;
#endif
#endif
/******************************************************************************
*							  F U N C T I O N S
*******************************************************************************
*/

/* Used as host uart param setup callback */
int setup_uart_param(
	int hComPort,
	int iBaudrate,
	struct UART_CONFIG *sUartConfig)
{
	struct termios ti;
	int  fd;

	printf("setup_uart_param begin\n");
	if (!sUartConfig) {
		perror("Invalid stpUartConfig");
		return -2;
	}

	printf("setup_uart_param %d %d\n",
			sUartConfig->iBaudrate, sUartConfig->fc);

	fd = hComPort;
	if (fd < 0) {
		perror("Invalid serial port");
		return -2;
	}

	tcflush(fd, TCIOFLUSH);

	if (tcgetattr(fd, &ti) < 0) {
		perror("Can't get port settings");
		return -3;
	}

	cfmakeraw(&ti);

	printf("ti.c_cflag = 0x%08x\n", ti.c_cflag);
	ti.c_cflag |= CLOCAL;
	printf("CLOCAL = 0x%x\n", CLOCAL);
	printf("(ori)ti.c_iflag = 0x%08x\n", ti.c_iflag);
	printf("(ori)ti.c_cflag = 0x%08x\n", ti.c_cflag);
	printf("stpUartConfig->fc= %d (0:none,sw,hw,linux)\n",
			sUartConfig->fc);

	if (sUartConfig->fc == UART_DISABLE_FC) {
		ti.c_cflag &= ~CRTSCTS;
		ti.c_iflag &= ~(0x80000000);
	} else if (sUartConfig->fc == UART_MTK_SW_FC) {
		ti.c_cflag &= ~CRTSCTS;
		ti.c_iflag |= 0x80000000; /* MTK Software FC */
	} else if (sUartConfig->fc == UART_HW_FC) {
		printf("stpUartConfig->fc is UART_HW_FC\n");
		ti.c_cflag |= CRTSCTS;	  /* RTS, CTS Enable */
		ti.c_iflag &= ~(0x80000000);
	} else if (sUartConfig->fc == UART_LINUX_FC) {
		ti.c_iflag |= (IXON | IXOFF | IXANY); /* Linux Software FC */
		ti.c_cflag &= ~CRTSCTS;
		ti.c_iflag &= ~(0x80000000);
	} else {
		ti.c_cflag &= ~CRTSCTS;
		ti.c_iflag &= ~(0x80000000);
	}

	printf("c_c CRTSCTS = 0x%16x\n", CRTSCTS);
	printf("c_i IXON = 0x%08x\n", IXON);
	printf("c_i IXOFF = 0x%08x\n", IXOFF);
	printf("c_i IXANY = 0x%08x\n", IXANY);
	printf("(aft)ti.c_iflag = 0x%08x\n", ti.c_iflag);
	printf("(aft)ti.c_cflag = 0x%08x\n\n", ti.c_cflag);

	if (tcsetattr(fd, TCSANOW, &ti) < 0) {
		perror("Can't set port settings");
		return -4;
	}

	/* Set baudrate */
	if (set_speed(fd, &ti, sUartConfig->iBaudrate) < 0) {
		perror("Can't set initial baud rate");
		return -5;
	}

	tcflush(fd, TCIOFLUSH);
	printf("%s done\n\n", __func__);
	return 0;
}

static speed_t get_speed(int baudrate)
{
	unsigned int idx;

	for (idx = 0; idx < sizeof(speeds)/sizeof(speeds[0]); idx++) {
		if (baudrate == (int)speeds[idx].baud)
			return speeds[idx].speed;
	}
	return CBAUDEX;
}

int set_speed(int fd, struct termios *ti, int speed)
{
	struct serial_struct ss;
	int baudenum = get_speed(speed);

	if (speed != CBAUDEX) {
		if ((ioctl(fd, TIOCGSERIAL, &ss)) < 0) {
			printf("%s: BAUD: error to get the serial_struct info:%s\n",
					__func__, strerror(errno));
			return -1;
		}
#ifdef ANDROID
		ss.flags &= ~ASYNC_SPD_CUST;
#if defined(SERIAL_STRUCT_EXT) /* modified in serial_struct.h */
		memset(ss.reserved, 0x00, sizeof(ss.reserved));
#endif
		ss.flags |= (1 << 13);
		/* set UPFLOWLATENCY flat to tty,
		 * or serial_core will reset tty->low_latency to 0
		 */
		/* set standard buadrate setting */
		if ((ioctl(fd, TIOCSSERIAL, &ss)) < 0) {
			printf("%s: BAUD: error to set serial_struct:%s\n",
				__func__, strerror(errno));
			return -2;
		}
#endif
		cfsetospeed(ti, baudenum);
		cfsetispeed(ti, baudenum);
		return tcsetattr(fd, TCSANOW, ti);
	}

	printf("%s: unsupported non-standard baudrate: %d -> 0x%08x\n",
			__func__, speed, baudenum);
	return -3;
}

int cmd_hdr_baud(struct UART_CONFIG *sUartConfig, int baudrate)
{

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, baudrate, sUartConfig) : -1;
}

#if 0
int cmd_hdr_baud_115k(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 115200, gStpUartConfig) : -1;
}

int cmd_hdr_baud_921k(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 921600, gStpUartConfig) : -1;
}

int cmd_hdr_baud_2kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 2000000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_2_5kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 2500000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_3kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
	? setup_uart_param(gTtyFd, 3000000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_3_2kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 3200000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_3_25kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 3250000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_3_5kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 3500000, gStpUartConfig) : -1;
}

int cmd_hdr_baud_4kk(struct STP_PARAMS_CONFIG *pStpParamsConfig)
{
	struct STP_UART_CONFIG *gStpUartConfig = &pStpParamsConfig->sUartConfig;

	return (gTtyFd != -1)
		? setup_uart_param(gTtyFd, 4000000, gStpUartConfig) : -1;
}
#endif

static void btuart_wake_lock(void)
{
	system("echo btmtk_uart > /sys/power/wake_lock");
}

static void btuart_wake_unlock(void)
{
	system("echo btmtk_uart > /sys/power/wake_unlock");
}

#define N_MTK		(15+1)
int main(int argc, char *argv[])
{
	printf("build date %s time %s\n", __DATE__, __TIME__);
	FILE *fscript = 0;
	int ld = 0;
	unsigned char cmd[2] = {0};
	struct pollfd fds;
	int fd_num = 0;
	int err = 0;
	int opt;
	int baudrate = 0;
	int chang_baud_rate = 0;
	int flow_control = 0;
	int download_flash = 0;
	int stp_enable = 0;
	int ccci_enable = 0;
	char *tty_path = "/dev/ttyUSB0";
	struct UART_CONFIG sUartConfig;

	memset(&sUartConfig, 0, sizeof(struct UART_CONFIG));
	memset(&fds, 0, sizeof(struct pollfd));

	while ((opt = getopt(argc, argv, "c:f:p:d::s::i::")) != -1) {
		switch (opt) {
		/* debug */
		case 'c':
			printf("baudrate = %d\n", baudrate);
			baudrate = atoi(optarg);
			printf("baudrate = %d\n", baudrate);
			chang_baud_rate = 1;
			printf("baudrate = %d\n", chang_baud_rate);
			break;
		/* command Usage */
		case 'f':
			flow_control = atoi(optarg);
			printf("flow_control = %d\n", flow_control);
			sUartConfig.fc = flow_control;
			break;
		case 'p':
			/* command Usage */
			tty_path = optarg;
			printf("Log path is %s\n", tty_path);
			break;
		case 'd':
			/* command Usage */
			download_flash = 1;
			printf("download_flash enable\n");
			break;
		case 's':
			/* command Usage */
			stp_enable = 1;
			printf("stp header enable\n");
			break;
		case 'i':
			/* command Usage */
			ccci_enable = 1;
			printf("ccci enable\n");
			break;
		case '?':
		default:
			printf("uart_launcher -c <baudrate> -f <0-3> -p <uart device> -d -s\n");
			printf("\t -c Set baudrate. 115200 is default, and not need set\n");
			printf("\t -f Set uart flow control.If STP enabled, please use -f 3\n");
			printf("\t -p set uart node. Ex. /dev/ttyS1\n");
			printf("\t -d Support download fw patch to flash\n");
			printf("\t -s Support STP\n");
		}
	}

	/* open ttyUSB */
	printf("Running...\n");
	gTtyFd = open(tty_path, O_RDWR | O_NOCTTY | O_NONBLOCK);
	printf("open done ttyfd %d\n", gTtyFd);
	if (gTtyFd < 0) {
		printf("ttyfd %d, error\n", gTtyFd);
		return 0;
	}

	ld = N_MTK;
	if (ioctl(gTtyFd, TIOCSETD, &ld) < 0) {
		printf("set TIOCSETD N_MTK error\n");
		return 0;
	}

	fds.fd = gTtyFd;
	fds.events = POLLIN;
	++fd_num;

restart:
	btuart_wake_lock();
	/* Set default Baud rate */
	sUartConfig.iBaudrate = CUST_BAUDRATE_DFT;
	printf("set baudtate = %d\n", CUST_BAUDRATE_DFT);
	cmd_hdr_baud(&sUartConfig, CUST_BAUDRATE_DFT);

	if (stp_enable == 1) {
		if (ioctl(gTtyFd, HCIUARTSTPENABLE, NULL) < 0) {
			printf("set HCIUARTSTPENABLE error\n");
			goto exit;
		}
	}

	ld = N_MTK;

	/* chang baud rate */
	if (chang_baud_rate) {
		sUartConfig.iBaudrate = baudrate;
		if (ioctl(gTtyFd, HCIUARTSETBAUD, &sUartConfig) < 0) {
			printf("set HCIUARTSETBAUD error\n");
			goto exit;
		}

		printf("set baudtate %d\n", baudrate);
		cmd_hdr_baud(&sUartConfig, baudrate);

		/* fds.fd = gTtyFd; */
		/* fds.events = POLLERR | POLLHUP; */
#if 0
		if (ioctl(gTtyFd, HCIUARTGETBAUD, NULL) < 0) {
			printf("set HCIUARTSETBAUD error\n");
			goto exit;
		}
#endif

		if (ioctl(gTtyFd, HCIUARTSETWAKEUP, NULL) < 0) {
			printf("set HCIUARTSETWAKEUP error\n");
			goto exit;
		}
	}

	if (stp_enable == 1) {
		if (ioctl(gTtyFd, HCIUARTSETSTP, NULL) < 0) {
			printf("set HCIUARTSETSTP error\n");
			goto exit;
		}
	}

	if (ioctl(gTtyFd, HCIUARTLOADPATCH, NULL) < 0) {
		printf("set HCIUARTLOADPATCH error\n");
		goto exit;
	}

	/* write(gTtyFd, cmd , sizeof(cmd)) ;*/
	if (download_flash == 1) {
		if (ioctl(gTtyFd, HCIUARTLOADFLASH, NULL) < 0) {
			printf("set HCIUARTLOADFLASH error\n");
			goto exit;
		}
	}

	if (ccci_enable == 1) {
		if (ioctl(gTtyFd, HCIUARTCCCI, NULL) < 0) {
			printf("set ccci error\n");
			goto exit;
		}
	}

	btuart_wake_unlock();

	while (1) {
		err = poll(&fds, fd_num, 2000);
		if (err < 0) {
			if (errno == EINTR) {
				continue;
			} else {
				printf("poll error:%d errno:%d, %s\n",
					err, errno, strerror(errno));
				break;
			}
		} else {
			if (fds.revents & POLLIN)
				goto restart;
			else
				continue;
		}
	}
exit:
	btuart_wake_unlock();
	return 0;
}

